<p data-lang-en="Copyright © 2025 Jinka University Graduate Credentials Verification. All rights reserved." 
           data-lang-am="© 2025 ጂንካ ዩኒቨርሲቲ የተመራቂዎች ማረጋገጫ። ሁሉም መብቶች የተጠበቁ ናቸው።">
            Copyright © 2025 Jinka University Graduate Credentials Verification. All rights reserved.
        </p>
        <p data-lang-en="Designed by Group 8: Bikila, Kedir, Hayimanot" data-lang-am="የተነደፈው በቡድን 8: ቢቂላ፣ ከድር፣ ሃይማኖት">Designed by Group 8: Bikila, Kedir, Hayimanot</p>
        <p>E-mail: <a href="mailto:group8csjku@gmail.com">group8csjku@gmail.com</a></p>
   