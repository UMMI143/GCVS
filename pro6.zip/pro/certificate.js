let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        const text = element.getAttribute('data-lang-' + currentLang);
        if (element.tagName === 'INPUT') {
            element.placeholder = text;
        } else {
            element.textContent = text;
        }
    });
}

function fetchCertificate() {
    const gradId = document.getElementById("certificate-id").value.trim();
    const previewDiv = document.getElementById("certificate-preview");

    if (!gradId) {
        previewDiv.innerHTML = `<p class="error">${currentLang === 'en' ? 'Please enter a valid Graduate ID.' : 'እባክዎ ትክክለኛ የተመራቂ መለያ ቁጥር ያስገቡ።'}</p>`;
        previewDiv.style.display = "block";
        return;
    }

    fetch("certificate.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "id=" + encodeURIComponent(gradId)
    })
    .then(response => response.json())
    .then(data => {
        previewDiv.style.display = "block";
        if (data.status === "success") {
            const certContent = currentLang === 'en' ? `
                <div class="certificate-header">
                    <img src="assets/img/logo.jpg" alt="Jinka University Logo" class="left-logo">
                    <img src="assets/img/logo.jpg" alt="Jinka University Logo" class="right-logo">
                    <h1>Jinka University</h1>
                    <h1>ጂንካ ዩኒቨርሲቲ</h1>
                    <h4>OFFICE OF THE REGISTRAR</h4>
                    <h4>ሬጅስትራር ጽ/ቤት</h4>
                    <hr><hr>
                </div>
                <div class="certificate-body">
                    <div class="certificate-body-en">
                        ${data.data.photo ? `<div class="photo"><img src="uploads/${data.data.photo}" alt="Graduate Photo"></div>` : ""}
                        <h5><u>To Whom It May Concern</u></h5>
                        <p>This Certificate is issued to Mr./Ms. <u>${data.data.name}</u> 
                        upon his/her graduation with a <strong>${data.data.qualification} in 
                        ${data.data.department}</strong> in the <strong>${data.data.program}</strong> 
                        program on Graduation Date: ${data.data.graduation_date}. His/Her CGPA is ${data.data.cgpa} 
                        and has passed the Exit Exam result of (${data.data.exit_exam}). Cost Share Status: 
                        <strong>${data.data.cost_share}</strong>.</p>
                        <p align="center">Sincerely</p>
                    </div>
                    <div class="certificate-body-am">
                        <h5><u>ለሚመለከተው ሁሉ</u></h5>
                        <p>አቶ/ወ/ሮ <u>${data.data.name}</u> <strong>${data.data.qualification} በ${data.data.department}</strong> በ<strong>${data.data.program}</strong> መርሃ-ግብር በ${data.data.graduation_date} በመመረቃቸው ይህ ምስክር ወረቀት ተሰጥቷቸዋል። በአጠቃላይ አማካይ ውጤታቸው ${data.data.cgpa} ሲሆን የመውጫ ፈተና (${data.data.exit_exam}) በማምጣት አልፈዋል። የወጪ መጋራት ሁኔታ: <strong>${data.data.cost_share === 'paid' ? 'ተከፍሏል' : 'አልተከፈለም'}</strong>።</p>
                        <p align="center">ከሰላምታ ጋር</p>
                    </div>
                    <div class="stamp">
                        <u><img src="assets/img/stamb.jpg" alt="Official Stamp"></u>
                        <hr width="200">
                        <p>University Registrar</p>    
                </div>
                </div> <br><hr><hr>
                <div class="certificate-footer">
                    <div class="pv">
                        <p><img src="assets/img/phone.png" alt="">251918661339 <br>
                    verification code:${data.data.verification_code} </p>
                 
                </div>
                <div class="print-controls">
                    <button class="btn" onclick="printCertificate()">Print Certificate</button>
                </div>
            ` : `
                <div class="certificate-header">
                    <img src="assets/img/logo.jpg" alt="Jinka University Logo" class="left-logo">
                    <img src="assets/img/logo.jpg" alt="Jinka University Logo" class="right-logo">
                    <h1>ጂንካ ዩኒቨርሲቲ</h1>
                    <h4>ሬጅስትራር ጽ/ቤት</h4>
                    <hr><hr>
                </div>
                <div class="certificate-body">
                    <div class="certificate-body-am">
                        <h5><u>ለሚመለከተው ሁሉ</u></h5>
                        <p>አቶ/ወ/ሮ <u>${data.data.name}</u> <strong>${data.data.qualification} በ${data.data.department}</strong> በ<strong>${data.data.program}</strong> መርሃ-ግብር በ${data.data.graduation_date} በመመረቃቸው ይህ ምስክር ወረቀት ተሰጥቷቸዋል። በአጠቃላይ አማካይ ውጤታቸው ${data.data.cgpa} ሲሆን የመውጫ ፈተና (${data.data.exit_exam}) በማምጣት አልፈዋል። የወጪ መጋራት ሁኔታ: <strong>${data.data.cost_share === 'paid' ? 'ተከፍሏል' : 'አልተከፈለም'}</strong>።</p>
                        <p align="center">ከሰላምታ ጋር</p>
                    </div>
                    <div class="stamp">
                        <img src="assets/img/stamb.jpg" alt="Official Stamp">
                        <p>የሪጂስትራር ፊርማ</p>
                    </div>
                    <hr><hr>
                </div>
                <div class="certificate-footer">
                    <div class="signature">
                        <img src="assets/img/signature.png" alt="">
                        <p>የዲን ፊርማ <br>
                        verification code:${data.data.verification_code} </p>
                    </div>
                </div>
                <div class="print-controls">
                    <button class="btn" onclick="printCertificate()">ምስክር ወረቀት ያትሙ</button>
                   
                </div>
            `;
            previewDiv.innerHTML = certContent;
        } else {
            previewDiv.innerHTML = `<p class="error">${data.message}</p>`;
        }
    })
    .catch(error => {
        previewDiv.innerHTML = `<p class="error">${currentLang === 'en' ? 'An error occurred. Please try again.' : 'ስህተት ተከስቷል። እባክዎ እንደገና ሞክር።'}</p>`;
        previewDiv.style.display = "block";
    });
}

function printCertificate() {
    window.print();
}

