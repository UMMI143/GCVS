let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        const text = element.getAttribute('data-lang-' + currentLang);
        if (element.tagName === 'INPUT') {
            element.placeholder = text;
        } else {
            element.textContent = text;
        }
    });
}

function verifyCredentials() {
    const verificationCode = document.getElementById("verification-code").value.trim();
    const resultDiv = document.getElementById("verification-result");

    if (!verificationCode) {
        resultDiv.innerHTML = `
            <div class="content">
                <div class="info">${currentLang === 'en' ? "Please enter a valid verification code." : "እባክህ ትክክለኛ ማረጋገጫ ኮድ አስገባ።"}</div>
            </div>
        `;
        resultDiv.className = "result-preview error";
        resultDiv.style.display = "block";
        return;
    }

    fetch("verify.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "code=" + encodeURIComponent(verificationCode)
    })
    .then(response => response.json())
    .then(data => {
        resultDiv.style.display = "block";
        if (data.status === "success") {
            if (data.type === "graduate") {
                resultDiv.innerHTML = currentLang === 'en' ? `
                    <div class="content">
                        <div class="photo">
                            ${data.data.photo ? `<img src="uploads/${data.data.photo}" alt="Photo">` : '<p>No Photo Available</p>'}
                            <div class="university-logo">
                                <img src="assets/img/logo.jpg" alt="Jinka University Logo">
                                <span>Jinka University</span>
                            </div>
                        </div>
                        <div class="info">
                            <span><strong>Graduate Found:</strong></span>
                            <span><strong>Verification Code:</strong> ${data.data.verification_code}</span>
                            <span><strong>Name:</strong> ${data.data.name ?? 'N/A'}</span>
                            <span><strong>CGPA:</strong> ${data.data.cgpa ?? 'N/A'}</span>
                            <span><strong>Exit Exam:</strong> ${data.data.exit_exam ?? 'N/A'}</span>
                            <span><strong>Qualification:</strong> ${data.data.qualification ?? 'N/A'}</span>
                            <span><strong>Department:</strong> ${data.data.department ?? 'N/A'}</span>
                            <span><strong>Gender:</strong> ${data.data.gender ?? 'N/A'}</span>
                            <span><strong>Graduation Date:</strong> ${data.data.graduation_date ?? 'N/A'}</span>
                            <span><strong>Program:</strong> ${data.data.program ?? 'N/A'}</span>
                            <span><strong>Cost Share Status:</strong> ${data.data.cost_share ?? 'N/A'}</span>
                        </div>
                    </div>
                ` : `
                    <div class="content">
                        <div class="photo">
                            ${data.data.photo ? `<img src="uploads/${data.data.photo}" alt="Photo">` : '<p>ፎቶ የለም</p>'}
                            <div class="university-logo">
                                <img src="assets/img/logo.jpg" alt="Jinka University Logo">
                                <span>ጂንካ ዩኒቨርሲቲ</span>
                            </div>
                        </div>
                        <div class="info">
                            <span><strong>ተመራቂ ተገኝቷል:</strong></span>
                            <span><strong>ማረጋገጫ ኮድ:</strong> ${data.data.verification_code}</span>
                            <span><strong>ስም:</strong> ${data.data.name ?? 'የለም'}</span>
                            <span><strong>CGPA:</strong> ${data.data.cgpa ?? 'የለም'}</span>
                            <span><strong>መውጫ ፈተና:</strong> ${data.data.exit_exam ?? 'የለም'}</span>
                            <span><strong>ማስረጃ:</strong> ${data.data.qualification ?? 'የለም'}</span>
                            <span><strong>ዲፓርትመንት:</strong> ${data.data.department ?? 'የለም'}</span>
                            <span><strong>ፆታ:</strong> ${data.data.gender ?? 'የለም'}</span>
                            <span><strong>የመመረቂያ ቀን:</strong> ${data.data.graduation_date ?? 'የለም'}</span>
                            <span><strong>ፕሮግራም:</strong> ${data.data.program ?? 'የለም'}</span>
                            <span><strong>ወጪ መጋራት ሁኔታ:</strong> ${data.data.cost_share ?? 'የለም'}</span>
                        </div>
                    </div>
                `;
                resultDiv.className = "result-preview success";
            } else {
                resultDiv.innerHTML = currentLang === 'en' ? `
                    <div class="content">
                        <div class="photo">
                            ${data.data.photo ? `<img src="uploads/${data.data.photo}" alt="Photo">` : '<p>No Photo Available</p>'}
                            <div class="university-logo">
                                <img src="assets/img/logo.jpg" alt="Jinka University Logo">
                                <span>Jinka University</span>
                            </div>
                        </div>
                        <div class="info">
                            <span><strong>Student Found:</strong></span>
                            <span><strong>ID:</strong> ${data.data.id}</span>
                            <span><strong>Name:</strong> ${data.data.name ?? 'N/A'}</span>
                            <span><strong>GPA:</strong> ${data.data.gpa ?? 'N/A'}</span>
                            <span><strong>Department:</strong> ${data.data.department ?? 'N/A'}</span>
                            <span><strong>Gender:</strong> ${data.data.gender ?? 'N/A'}</span>
                            <span><strong>Entry Date:</strong> ${data.data.entry_date ?? 'N/A'}</span>
                            <span><strong>Cost Share Status:</strong> ${data.data.cost_share ?? 'N/A'}</span>
                            <span><strong>Program:</strong> ${data.data.program ?? 'N/A'}</span>
                        </div>
                    </div>
                ` : `
                    <div class="content">
                        <div class="photo">
                            ${data.data.photo ? `<img src="uploads/${data.data.photo}" alt="Photo">` : '<p>ፎቶ የለም</p>'}
                            <div class="university-logo">
                                <img src="assets/img/logo.jpg" alt="Jinka University Logo">
                                <span>ጂንካ ዩኒቨርሲቲ</span>
                            </div>
                        </div>
                        <div class="info">
                            <span><strong>ተማሪ ተገኝቷል:</strong></span>
                            <span><strong>መለያ:</strong> ${data.data.id}</span>
                            <span><strong>ስም:</strong> ${data.data.name ?? 'የለም'}</span>
                            <span><strong>GPA:</strong> ${data.data.gpa ?? 'የለም'}</span>
                            <span><strong>ዲፓርትመንት:</strong> ${data.data.department ?? 'የለም'}</span>
                            <span><strong>ፆታ:</strong> ${data.data.gender ?? 'የለም'}</span>
                            <span><strong>የመግቢያ ቀን:</strong> ${data.data.entry_date ?? 'የለም'}</span>
                            <span><strong>ወጪ መጋራት ሁኔታ:</strong> ${data.data.cost_share ?? 'የለም'}</span>
                            <span><strong>ፕሮግራም:</strong> ${data.data.program ?? 'የለም'}</span>
                        </div>
                    </div>
                `;
                resultDiv.className = "result-preview success";
            }
        } else {
            resultDiv.innerHTML = `
                <div class="content">
                    <div class="info">${currentLang === 'en' ? data.message : "ምንም መዝገብ ለማረጋገጫ ኮድ አልተገኘም: " + data.message.split(":")[1]}</div>
                </div>
            `;
            resultDiv.className = "result-preview error";
        }
    })
    .catch(error => {
        resultDiv.innerHTML = `
            <div class="content">
                <div class="info">${currentLang === 'en' ? "An error occurred. Please try again." : "ስህተት ተከስቷል። እባክህ እንደገና ሞክር።"}</div>
            </div>
        `;
        resultDiv.className = "result-preview error";
        resultDiv.style.display = "block";
    });
}