<?php
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$autoloadPath = 'phpspreadsheet/vendor/autoload.php';
if (!file_exists($autoloadPath)) {
    die("Error: PhpSpreadsheet not installed. Run these commands:
        1. cd C:\\xampp\\htdocs\\pro\\phpspreadsheet
        2. composer require phpoffice/phpspreadsheet");
}

require $autoloadPath;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;

require_once 'db_connect.php';
$db = (new Database())->connect();

$uploadDir = "uploads/";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$message = "";
$editData = null;

function generateVerificationCode($db) {
    try {
        $stmt = $db->query("SELECT MAX(CAST(SUBSTRING(verification_code, 4) AS UNSIGNED)) as max_code FROM graduates");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $nextNum = ($result['max_code'] ?? 0) + 1;
        return "JkU" . str_pad($nextNum, 3, "0", STR_PAD_LEFT);
    } catch (PDOException $e) {
        return false;
    }
}

// Edit ID
if (isset($_GET["edit_id"])) {
    $editId = filter_input(INPUT_GET, "edit_id", FILTER_SANITIZE_STRING);
    try {
        $stmt = $db->prepare("SELECT * FROM graduates WHERE id = ?");
        $stmt->execute([$editId]);
        $editData = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$editData) {
            $message = "Graduate not found! | ተመራቂ አልተገኘም!";
        }
    } catch (PDOException $e) {
        $message = "Database error: " . $e->getMessage();
    }
}

// Add graduate with ID validation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_grad"])) {
    try {
        $gradId = filter_input(INPUT_POST, "grad-id", FILTER_SANITIZE_STRING);
        $gradProgram = filter_input(INPUT_POST, "grad-program", FILTER_SANITIZE_STRING);

        if (empty($gradId) || empty($gradProgram)) throw new Exception("Graduate ID and Program are required!");

        if ($gradProgram === "Regular" && !preg_match("/^UGR/", $gradId)) {
            throw new Exception("Regular program ID must start with 'UGR'!");
        } elseif ($gradProgram === "Weekend" && !preg_match("/^UGW/", $gradId)) {
            throw new Exception("Weekend program ID must start with 'UGW'!");
        } elseif ($gradProgram === "Summer" && !preg_match("/^UGS/", $gradId)) {
            throw new Exception("Summer program ID must start with 'UGS'!");
        }

        $checkStmt = $db->prepare("SELECT COUNT(*) FROM graduates WHERE id = ?");
        $checkStmt->execute([$gradId]);
        if ($checkStmt->fetchColumn() > 0) {
            throw new Exception("Graduate ID '$gradId' already exists! | የተመራቂ መለያ '$gradId' አስቀድሞ አለ!");
        }

        $gradName = filter_input(INPUT_POST, "grad-name", FILTER_SANITIZE_STRING);
        $gradCgpa = filter_input(INPUT_POST, "grad-cgpa", FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $gradExam = filter_input(INPUT_POST, "grad-exam", FILTER_SANITIZE_STRING);
        $gradQualification = filter_input(INPUT_POST, "grad-qualification", FILTER_SANITIZE_STRING);
        $gradDept = filter_input(INPUT_POST, "grad-dept", FILTER_SANITIZE_STRING);
        $gradGender = filter_input(INPUT_POST, "grad-gender", FILTER_SANITIZE_STRING);
        $gradDate = filter_input(INPUT_POST, "grad-date", FILTER_SANITIZE_STRING);
        $gradCostShare = filter_input(INPUT_POST, "grad-cost-share", FILTER_SANITIZE_STRING);

        if (empty($gradName) || empty($gradCgpa) || empty($gradExam) || empty($gradQualification) || 
            empty($gradDept) || empty($gradGender) || empty($gradDate) || empty($gradCostShare)) {
            throw new Exception("All fields are required!");
        }

        if ($gradCgpa < 2.0 || $gradCgpa > 4.0) {
            throw new Exception("CGPA must be between 2.0 and 4.0! | CGPA ከ2.0 እስከ 4.0 መሆን አለበት!");
        }

        $verificationCode = generateVerificationCode($db);
        if ($verificationCode === false) throw new Exception("Failed to generate verification code!");

        $gradPhoto = "";
        if (!empty($_FILES["grad-photo"]["name"])) {
            $fileExt = strtolower(pathinfo($_FILES["grad-photo"]["name"], PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($fileExt, $allowedExt)) {
                throw new Exception("Invalid file type! Only JPG, JPEG, PNG, and GIF allowed.");
            }
            $gradPhoto = uniqid() . '.' . $fileExt;
            $target = $uploadDir . $gradPhoto;
            if (!move_uploaded_file($_FILES["grad-photo"]["tmp_name"], $target)) {
                throw new Exception("Failed to upload photo! | ፎቶ መስቀል አልተሳካም!");
            }
        }

        $stmt = $db->prepare("INSERT INTO graduates (id, name, cgpa, exit_exam, qualification, department, gender, graduation_date, cost_share, photo, verification_code, program) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$gradId, $gradName, $gradCgpa, $gradExam, $gradQualification, $gradDept, $gradGender, $gradDate, $gradCostShare, $gradPhoto, $verificationCode, $gradProgram]);
        $message = "Graduate added successfully! Verification Code: $verificationCode | ተመራቂ በተሳካ ሁኔታ ተጨምሯል! ማረጋገጫ ኮድ: $verificationCode";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Update graduate with ID validation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_grad"])) {
    try {
        $gradId = filter_input(INPUT_POST, "grad-id", FILTER_SANITIZE_STRING);
        $gradProgram = filter_input(INPUT_POST, "grad-program", FILTER_SANITIZE_STRING);

        if (empty($gradId) || empty($gradProgram)) throw new Exception("Graduate ID and Program are required!");

        if ($gradProgram === "Regular" && !preg_match("/^UGR/", $gradId)) {
            throw new Exception("Regular program ID must start with 'UGR'!");
        } elseif ($gradProgram === "Weekend" && !preg_match("/^UGW/", $gradId)) {
            throw new Exception("Weekend program ID must start with 'UGW'!");
        } elseif ($gradProgram === "Summer" && !preg_match("/^UGS/", $gradId)) {
            throw new Exception("Summer program ID must start with 'UGS'!");
        }

        $gradName = filter_input(INPUT_POST, "grad-name", FILTER_SANITIZE_STRING);
        $gradCgpa = filter_input(INPUT_POST, "grad-cgpa", FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $gradExam = filter_input(INPUT_POST, "grad-exam", FILTER_SANITIZE_STRING);
        $gradQualification = filter_input(INPUT_POST, "grad-qualification", FILTER_SANITIZE_STRING);
        $gradDept = filter_input(INPUT_POST, "grad-dept", FILTER_SANITIZE_STRING);
        $gradGender = filter_input(INPUT_POST, "grad-gender", FILTER_SANITIZE_STRING);
        $gradDate = filter_input(INPUT_POST, "grad-date", FILTER_SANITIZE_STRING);
        $gradCostShare = filter_input(INPUT_POST, "grad-cost-share", FILTER_SANITIZE_STRING);

        if (empty($gradName) || empty($gradCgpa) || empty($gradExam) || empty($gradQualification) || 
            empty($gradDept) || empty($gradGender) || empty($gradDate) || empty($gradCostShare)) {
            throw new Exception("All fields are required!");
        }

        if ($gradCgpa < 2.0 || $gradCgpa > 4.0) {
            throw new Exception("CGPA must be between 2.0 and 4.0! | CGPA ከ2.0 እስከ 4.0 መሆን አለበት!");
        }

        $gradPhoto = filter_input(INPUT_POST, "existing-photo", FILTER_SANITIZE_STRING);
        if (!empty($_FILES["grad-photo"]["name"])) {
            $fileExt = strtolower(pathinfo($_FILES["grad-photo"]["name"], PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($fileExt, $allowedExt)) {
                throw new Exception("Invalid file type! Only JPG, JPEG, PNG, and GIF allowed.");
            }
            $gradPhoto = uniqid() . '.' . $fileExt;
            $target = $uploadDir . $gradPhoto;
            if (!move_uploaded_file($_FILES["grad-photo"]["tmp_name"], $target)) {
                throw new Exception("Failed to upload new photo! | አዲስ ፎቶ መስቀል አልተሳካም!");
            }
            if (!empty($_POST["existing-photo"]) && file_exists($uploadDir . $_POST["existing-photo"])) {
                unlink($uploadDir . $_POST["existing-photo"]);
            }
        }

        $stmt = $db->prepare("UPDATE graduates SET name=?, cgpa=?, exit_exam=?, qualification=?, department=?, gender=?, graduation_date=?, cost_share=?, photo=?, program=? WHERE id=?");
        $stmt->execute([$gradName, $gradCgpa, $gradExam, $gradQualification, $gradDept, $gradGender, $gradDate, $gradCostShare, $gradPhoto, $gradProgram, $gradId]);
        $message = "Graduate updated successfully! | ተመራቂ በተሳካ ሁኔታ ተዘምኗል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Delete single graduate
if (isset($_GET["delete_grad"])) {
    try {
        $gradId = filter_input(INPUT_GET, "delete_grad", FILTER_SANITIZE_STRING);
        if (empty($gradId)) throw new Exception("Graduate ID is required!");

        $stmt = $db->prepare("SELECT photo FROM graduates WHERE id = ?");
        $stmt->execute([$gradId]);
        $photo = $stmt->fetchColumn();

        $stmt = $db->prepare("DELETE FROM graduates WHERE id = ?");
        $stmt->execute([$gradId]);

        if ($photo && file_exists($uploadDir . $photo)) {
            unlink($uploadDir . $photo);
        }

        $message = "Graduate deleted successfully! | ተመራቂ በተሳካ ሁኔታ ተሰርዟል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Delete multiple graduates
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_selected"])) {
    try {
        if (!isset($_POST["selected_graduates"]) || empty($_POST["selected_graduates"])) {
            throw new Exception("No graduates selected for deletion!");
        }

        $selectedIds = $_POST["selected_graduates"];
        $placeholders = str_repeat('?,', count($selectedIds) - 1) . '?';

        $stmt = $db->prepare("SELECT id, photo FROM graduates WHERE id IN ($placeholders)");
        $stmt->execute($selectedIds);
        $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $db->prepare("DELETE FROM graduates WHERE id IN ($placeholders)");
        $stmt->execute($selectedIds);

        foreach ($photos as $photo) {
            if ($photo['photo'] && file_exists($uploadDir . $photo['photo'])) {
                unlink($uploadDir . $photo['photo']);
            }
        }

        $message = "Selected graduates deleted successfully! | ተመረጡት ተመራቂዎች በተሳካ ሁኔታ ተሰርዘዋል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Export to Excel for specific program
if (isset($_GET["export_program"])) {
    try {
        $program = filter_input(INPUT_GET, "export_program", FILTER_SANITIZE_STRING);
        if (!in_array($program, ['Regular', 'Weekend', 'Summer'])) {
            throw new Exception("Invalid program specified!");
        }

        if (!class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
            throw new Exception("PhpSpreadsheet library is not loaded.");
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["Graduate ID", "Name", "CGPA", "Exit Exam", "Qualification", "Department", "Gender", "Graduation Date", "Cost Share", "Program", "Verification Code"];
        $sheet->fromArray($headers, NULL, 'A1');

        $stmt = $db->prepare("SELECT id, name, cgpa, exit_exam, qualification, department, gender, graduation_date, cost_share, program, verification_code FROM graduates WHERE program = ? ORDER BY id");
        $stmt->execute([$program]);
        $graduates = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $rowNum = 2;
        foreach ($graduates as $row) {
            $sheet->fromArray(array_values($row), NULL, 'A' . $rowNum);
            $rowNum++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = strtolower($program) . "_graduates_export_" . date('Ymd_His') . ".xlsx";
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
        exit;
    } catch (Exception $e) {
        $message = "Error exporting $program to Excel: " . $e->getMessage();
    }
}

// Import from Excel for specific program
if ($_SERVER["REQUEST_METHOD"] === "POST" && (isset($_FILES["import_file_regular"]) || isset($_FILES["import_file_weekend"]) || isset($_FILES["import_file_summer"]))) {
    try {
        $program = '';
        if (isset($_FILES["import_file_regular"])) {
            $program = 'Regular';
            $file = $_FILES["import_file_regular"]["tmp_name"];
            $fileName = $_FILES["import_file_regular"]["name"];
        } elseif (isset($_FILES["import_file_weekend"])) {
            $program = 'Weekend';
            $file = $_FILES["import_file_weekend"]["tmp_name"];
            $fileName = $_FILES["import_file_weekend"]["name"];
        } elseif (isset($_FILES["import_file_summer"])) {
            $program = 'Summer';
            $file = $_FILES["import_file_summer"]["tmp_name"];
            $fileName = $_FILES["import_file_summer"]["name"];
        }

        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if (!in_array($fileExt, ['xlsx', 'xls'])) {
            throw new Exception("Invalid file type! Only .xlsx and .xls files are allowed.");
        }

        $spreadsheet = IOFactory::load($file);
        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        $stmt = $db->prepare("INSERT INTO graduates (id, name, cgpa, exit_exam, qualification, department, gender, graduation_date, cost_share, program, verification_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        foreach ($sheetData as $rowNum => $row) {
            if ($rowNum === 1) continue;

            $gradId = $row['A'] ?? '';
            $gradName = $row['B'] ?? '';
            $gradCgpa = floatval($row['C'] ?? '');
            $gradExam = $row['D'] ?? '';
            $gradQualification = $row['E'] ?? '';
            $gradDept = $row['F'] ?? '';
            $gradGender = $row['G'] ?? '';
            $gradDate = $row['H'] ?? '';
            $gradCostShare = $row['I'] ?? '';
            $gradProgram = $program;

            if (empty($gradId) || empty($gradName) || empty($gradCgpa) || empty($gradExam) || empty($gradQualification) || 
                empty($gradDept) || empty($gradGender) || empty($gradDate) || empty($gradCostShare)) {
                continue;
            }

            if ($gradProgram === "Regular" && !preg_match("/^UGR/", $gradId)) {
                continue;
            } elseif ($gradProgram === "Weekend" && !preg_match("/^UGW/", $gradId)) {
                continue;
            } elseif ($gradProgram === "Summer" && !preg_match("/^UGS/", $gradId)) {
                continue;
            }

            if ($gradCgpa < 2.0 || $gradCgpa > 4.0) {
                continue;
            }

            $checkStmt = $db->prepare("SELECT COUNT(*) FROM graduates WHERE id = ?");
            $checkStmt->execute([$gradId]);
            if ($checkStmt->fetchColumn() > 0) {
                continue;
            }

            $verificationCode = generateVerificationCode($db);
            $stmt->execute([$gradId, $gradName, $gradCgpa, $gradExam, $gradQualification, $gradDept, $gradGender, $gradDate, $gradCostShare, $gradProgram, $verificationCode]);
        }
        $message = "$program data imported successfully! Rows with invalid IDs or CGPA < 2.0 were skipped.";
    } catch (Exception $e) {
        $message = "Error during $program import: " . $e->getMessage();
    }
}

// Fetch graduates by program
$regularStmt = $db->query("SELECT * FROM graduates WHERE program = 'Regular' ORDER BY id");
$regularGraduates = $regularStmt->fetchAll(PDO::FETCH_ASSOC);

$weekendStmt = $db->query("SELECT * FROM graduates WHERE program = 'Weekend' ORDER BY id");
$weekendGraduates = $weekendStmt->fetchAll(PDO::FETCH_ASSOC);

$summerStmt = $db->query("SELECT * FROM graduates WHERE program = 'Summer' ORDER BY id");
$summerGraduates = $summerStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-en="Graduates List - Jinka University" data-lang-am="የተመራቂዎች ዝርዝር - ጂንካ ዩኒቨርሲቲ">Graduates List - Jinka University</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/graduates_list.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="assets/js/graduates_list.js" defer></script>
</head>
<body style="background: rgb(235, 216, 235);">
<div class="container">
    <div class="top-bar">
        <h2 data-lang-en="Graduates List" data-lang-am="የተመራቂዎች ዝርዝር">Graduates List</h2>
        <div>
            <button class="btn lang-toggle" onclick="toggleLanguage()">En | አማ</button>
            <a href="dashboard.php" class="btn back-btn" data-lang-en="Back to Dashboard" data-lang-am="ወደ ዳሽቦርድ ተመለስ">Back to Dashboard</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="<?php echo strpos($message, 'Error') === false ? 'message' : 'error'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="manage-section" style="background: rgb(200, 200, 200);">
        <h3 data-lang-en="Graduate Information" data-lang-am="የተመራቂ መረጃ"><?php echo $editData ? 'Edit Graduate Information' : 'Add Graduate Information'; ?></h3>
        <form class="manage-form" method="post" enctype="multipart/form-data">
            <input type="text" name="grad-id" placeholder="Graduate ID (e.g., UGR123, UGW123, UGS123)" value="<?php echo htmlspecialchars($editData["id"] ?? ''); ?>" required <?php echo $editData ? 'readonly' : ''; ?>>
            <input type="text" name="grad-name" placeholder="Full Name" value="<?php echo htmlspecialchars($editData["name"] ?? ''); ?>" required>
            <input type="number" name="grad-cgpa" placeholder="CGPA" step="0.01" min="2.0" max="4.0" value="<?php echo htmlspecialchars($editData["cgpa"] ?? ''); ?>" required>
            <input type="text" name="grad-exam" placeholder="Exit Exam Result" value="<?php echo htmlspecialchars($editData["exit_exam"] ?? ''); ?>" required>
            <select name="grad-qualification" required>
                <option value="">Select Qualification</option>
                <option value="BSc" <?php echo ($editData && $editData["qualification"] === "BSc") ? 'selected' : ''; ?>>BSc</option>
                <option value="MSc" <?php echo ($editData && $editData["qualification"] === "MSc") ? 'selected' : ''; ?>>MSc</option>
            </select>
            <select name="grad-dept" required>
                <option value="">Select Department</option>
                <option value="Agricultural Economics" <?php echo ($editData && $editData["department"] === "Agricultural Economics") ? 'selected' : ''; ?>>Agricultural Economics</option>
                <option value="Animal Science" <?php echo ($editData && $editData["department"] === "Animal Science") ? 'selected' : ''; ?>>Animal Science</option>
                <option value="Natural Resource Management" <?php echo ($editData && $editData["department"] === "Natural Resource Management") ? 'selected' : ''; ?>>Natural Resource Management</option>
                <option value="Plant Science" <?php echo ($editData && $editData["department"] === "Plant Science") ? 'selected' : ''; ?>>Plant Science</option>
                <option value="Biology" <?php echo ($editData && $editData["department"] === "Biology") ? 'selected' : ''; ?>>Biology</option>
                <option value="Chemistry" <?php echo ($editData && $editData["department"] === "Chemistry") ? 'selected' : ''; ?>>Chemistry</option>
                <option value="Mathematics" <?php echo ($editData && $editData["department"] === "Mathematics") ? 'selected' : ''; ?>>Mathematics</option>
                <option value="Physics" <?php echo ($editData && $editData["department"] === "Physics") ? 'selected' : ''; ?>>Physics</option>
                <option value="English Language and Literature" <?php echo ($editData && $editData["department"] === "English Language and Literature") ? 'selected' : ''; ?>>English Language and Literature</option>
                <option value="Geography" <?php echo ($editData && $editData["department"] === "Geography") ? 'selected' : ''; ?>>Geography</option>
                <option value="History and Heritage Management" <?php echo ($editData && $editData["department"] === "History and Heritage Management") ? 'selected' : ''; ?>>History and Heritage Management</option>
                <option value="Accounting and Finance" <?php echo ($editData && $editData["department"] === "Accounting and Finance") ? 'selected' : ''; ?>>Accounting and Finance</option>
                <option value="Economics" <?php echo ($editData && $editData["department"] === "Economics") ? 'selected' : ''; ?>>Economics</option>
                <option value="Management" <?php echo ($editData && $editData["department"] === "Management") ? 'selected' : ''; ?>>Management</option>
                <option value="Health Officer" <?php echo ($editData && $editData["department"] === "Health Officer") ? 'selected' : ''; ?>>Health Officer</option>
                <option value="Midwife Nurse" <?php echo ($editData && $editData["department"] === "Midwife Nurse") ? 'selected' : ''; ?>>Midwife Nurse</option>
                <option value="Nursing" <?php echo ($editData && $editData["department"] === "Nursing") ? 'selected' : ''; ?>>Nursing</option>
                <option value="Computer Science" <?php echo ($editData && $editData["department"] === "Computer Science") ? 'selected' : ''; ?>>Computer Science</option>
                <option value="Anthropology" <?php echo ($editData && $editData["department"] === "Anthropology") ? 'selected' : ''; ?>>Anthropology</option>
                <option value="HPE" <?php echo ($editData && $editData["department"] === "HPE") ? 'selected' : ''; ?>>HPE</option>
                <option value="AgriBusiness" <?php echo ($editData && $editData["department"] === "AgriBusiness") ? 'selected' : ''; ?>>AgriBusiness</option>
                <option value="Law" <?php echo ($editData && $editData["department"] === "Law") ? 'selected' : ''; ?>>Law</option>
            </select>
            <select name="grad-gender" required>
                <option value="">Select Gender</option>
                <option value="Male" <?php echo ($editData && $editData["gender"] === "Male") ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($editData && $editData["gender"] === "Female") ? 'selected' : ''; ?>>Female</option>
            </select>
            <input type="text" name="grad-date" id="grad-date" placeholder="Graduation Date" value="<?php echo htmlspecialchars($editData["graduation_date"] ?? ''); ?>" required>
            <select name="grad-cost-share" required>
                <option value="">Cost Share Status</option>
                <option value="paid" <?php echo ($editData && $editData["cost_share"] === "paid") ? 'selected' : ''; ?>>Paid</option>
                <option value="unpaid" <?php echo ($editData && $editData["cost_share"] === "unpaid") ? 'selected' : ''; ?>>Unpaid</option>
            </select>
            <select name="grad-program" required>
                <option value="">Select Program</option>
                <option value="Regular" <?php echo ($editData && $editData["program"] === "Regular") ? 'selected' : ''; ?>>Regular</option>
                <option value="Weekend" <?php echo ($editData && $editData["program"] === "Weekend") ? 'selected' : ''; ?>>Weekend</option>
                <option value="Summer" <?php echo ($editData && $editData["program"] === "Summer") ? 'selected' : ''; ?>>Summer</option>
            </select>
            <input type="text" name="verification_code" placeholder="Verification Code" value="<?php echo htmlspecialchars($editData["verification_code"] ?? ''); ?>" readonly>
            <input type="file" name="grad-photo" accept="image/*">
            <input type="hidden" name="existing-photo" value="<?php echo htmlspecialchars($editData["photo"] ?? ''); ?>">
            <?php if ($editData): ?>
                <button type="submit" name="update_grad" class="btn update-btn" data-lang-en="Update Graduate" data-lang-am="ተመራቂ ዘምን">Update Graduate</button>
            <?php else: ?>
                <button type="submit" name="add_grad" class="btn add-btn" data-lang-en="Add Graduate" data-lang-am="ተመራቂ ጨምር">Add Graduate</button>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-container" style="background: rgb(200, 200, 200);">
        <h3 data-lang-en="Regular Students" data-lang-am="መደበኛ ተማሪዎች">Regular Students</h3>
        <div style="margin-bottom: 1rem;">
            <a href="?export_program=Regular" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
            <form method="post" enctype="multipart/form-data" style="display: inline;">
                <input type="file" name="import_file_regular" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
            </form>
        </div>
        <form method="post" id="deleteFormRegular">
            <div style="margin-bottom: 1rem;">
                <span class="select-all" onclick="toggleSelectAll('Regular')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                        onclick="return confirm('Are you sure you want to delete selected graduates?')" 
                        data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAllRegular" class="checkbox"></th>
                        <th data-lang-en="Graduate ID" data-lang-am="የተመራቂ መለያ">Graduate ID</th>
                        <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                        <th data-lang-en="CGPA" data-lang-am="CGPA">CGPA</th>
                        <th data-lang-en="Exit Exam" data-lang-am="የመውጫ ፈተና">Exit Exam</th>
                        <th data-lang-en="Qualification" data-lang-am="ማስረጃ">Qualification</th>
                        <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                        <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                        <th data-lang-en="Graduation Date" data-lang-am="የመመረቂያ ቀን">Graduation Date</th>
                        <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                        <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                        <th data-lang-en="Verification Code" data-lang-am="ማረጋገጫ ኮድ">Verification Code</th>
                        <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                        <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($regularGraduates as $row): ?>
                        <tr>
                            <td><input type="checkbox" name="selected_graduates[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox grad-checkbox-regular"></td>
                            <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cgpa"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["exit_exam"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["qualification"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["verification_code"] ?? ''); ?></td>
                            <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                            <td>
                                <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                <a href="?delete_grad=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </form>
    </div>

    <div class="table-container" style="background: rgb(200, 200, 200);">
        <h3 data-lang-en="Weekend Students" data-lang-am="የሳምንት መጨረሻ ተማሪዎች">Weekend Students</h3>
        <div style="margin-bottom: 1rem;">
            <a href="?export_program=Weekend" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
            <form method="post" enctype="multipart/form-data" style="display: inline;">
                <input type="file" name="import_file_weekend" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
            </form>
        </div>
        <form method="post" id="deleteFormWeekend">
            <div style="margin-bottom: 1rem;">
                <span class="select-all" onclick="toggleSelectAll('Weekend')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                        onclick="return confirm('Are you sure you want to delete selected graduates?')" 
                        data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAllWeekend" class="checkbox"></th>
                        <th data-lang-en="Graduate ID" data-lang-am="የተመራቂ መለያ">Graduate ID</th>
                        <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                        <th data-lang-en="CGPA" data-lang-am="CGPA">CGPA</th>
                        <th data-lang-en="Exit Exam" data-lang-am="የመውጫ ፈተና">Exit Exam</th>
                        <th data-lang-en="Qualification" data-lang-am="ማስረጃ">Qualification</th>
                        <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                        <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                        <th data-lang-en="Graduation Date" data-lang-am="የመመረቂያ ቀን">Graduation Date</th>
                        <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                        <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                        <th data-lang-en="Verification Code" data-lang-am="ማረጋገጫ ኮድ">Verification Code</th>
                        <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                        <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($weekendGraduates as $row): ?>
                        <tr>
                            <td><input type="checkbox" name="selected_graduates[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox grad-checkbox-weekend"></td>
                            <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cgpa"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["exit_exam"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["qualification"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["verification_code"] ?? ''); ?></td>
                            <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                            <td>
                                <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                <a href="?delete_grad=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </form>
    </div>

    <div class="table-container" style="background: rgb(200, 200, 200);">
        <h3 data-lang-en="Summer Students" data-lang-am="የበጋ ተማሪዎች">Summer Students</h3>
        <div style="margin-bottom: 1rem;">
            <a href="?export_program=Summer" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
            <form method="post" enctype="multipart/form-data" style="display: inline;">
                <input type="file" name="import_file_summer" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
            </form>
        </div>
        <form method="post" id="deleteFormSummer">
            <div style="margin-bottom: 1rem;">
                <span class="select-all" onclick="toggleSelectAll('Summer')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                        onclick="return confirm('Are you sure you want to delete selected graduates?')" 
                        data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAllSummer" class="checkbox"></th>
                        <th data-lang-en="Graduate ID" data-lang-am="የተመራቂ መለያ">Graduate ID</th>
                        <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                        <th data-lang-en="CGPA" data-lang-am="CGPA">CGPA</th>
                        <th data-lang-en="Exit Exam" data-lang-am="የመውጫ ፈተና">Exit Exam</th>
                        <th data-lang-en="Qualification" data-lang-am="ማስረጃ">Qualification</th>
                        <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                        <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                        <th data-lang-en="Graduation Date" data-lang-am="የመመረቂያ ቀን">Graduation Date</th>
                        <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                        <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                        <th data-lang-en="Verification Code" data-lang-am="ማረጋገጫ ኮድ">Verification Code</th>
                        <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                        <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($summerGraduates as $row): ?>
                        <tr>
                            <td><input type="checkbox" name="selected_graduates[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox grad-checkbox-summer"></td>
                            <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cgpa"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["exit_exam"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["qualification"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row["verification_code"] ?? ''); ?></td>
                            <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                            <td>
                                <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                <a href="?delete_grad=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </form>
    </div>
</div>
<footer style="background: black;">
<?php

include 'footer.php';

    ?>
</footer>
</body>
</html>