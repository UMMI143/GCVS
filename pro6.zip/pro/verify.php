<?php
$host = "localhost";
$dbname = "jinka_university";
$user = "root";
$pass = "";

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["code"])) {
    $verificationCode = filter_input(INPUT_POST, "code", FILTER_SANITIZE_STRING);
    $response = [];

    $stmt = $db->prepare("SELECT * FROM graduates WHERE verification_code = ?");
    $stmt->execute([$verificationCode]);
    $graduate = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$verificationCode]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($graduate) {
        $response = ["status" => "success", "type" => "graduate", "data" => $graduate];
    } elseif ($student) {
        $response = ["status" => "success", "type" => "student", "data" => $student];
    } else {
        $response = ["status" => "error", "message" => "No record found for Verification Code: $verificationCode"];
    }

    header("Content-Type: application/json");
    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jinka University Verification</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/verify.css">
</head>
<body>
    <header style="background: rgb(235, 216, 216);">
        <nav>
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Jinka University Logo" width="75" height="75">
                <span data-lang-en="Jinka University" data-lang-am="ጂንካ ዩኒቨርሲቲ">Jinka University</span>
            </div>
            <div class="nav-controls">
                <button class="btn lang-btn" onclick="toggleLanguage()">En | አማ</button>
            </div>
        </nav>
        <div class="hero-content">
            <h1 data-lang-en="Welcome to Jinka University Credential Verification System" 
                data-lang-am="እንኳን ወደ ጂንካ ዩኒቨርሲቲ የምስክር ወረቀት ማረጋገጫ በደህና መጡ።">
                Credential Verification Made Simple
            </h1>
            <p data-lang-en="Verify graduate and student details simply." 
               data-lang-am="የተመራቂዎችን እና የተማሪዎችን ዝርዝሮች በቀላሉ ያረጋግጡ ።">
                Verify graduate and student details simply.
            </p>
            <div class="verification-box">
                <input type="text" id="verification-code" 
                       data-lang-en="Enter Verification Code" data-lang-am="ማረጋገጫ ኮድ አስገባ" 
                       placeholder="Enter Verification Code">
                <button class="btn verify-btn" onclick="verifyCredentials()" 
                        data-lang-en="Verify Now" data-lang-am="አሁን አረጋግጥ">Verify Now</button>
            </div>
            <div class="result-preview" id="verification-result"></div>
        </div>
        <a href="index.html" class="btn back-btn" data-lang-en="Back to Home" data-lang-am="ወደ መነሻ ተመለስ">Back to Home</a>
    </header>

    <footer>
        <div class="footer-content">
        <?php

include 'footer.php';

    ?>
</div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="verify.js"></script>
</body>
</html>