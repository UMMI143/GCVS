let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        const text = element.getAttribute('data-lang-' + currentLang);
        if (element.tagName === 'A') {
            element.textContent = text;
        } else {
            element.innerHTML = text + (element.querySelector('a') ? ' <a href="' + element.querySelector('a').href + '">Click here</a>' : '');
        }
    });
}