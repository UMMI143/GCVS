let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        element.innerHTML = element.getAttribute('data-lang-' + currentLang);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    flatpickr("#grad-date", {
        dateFormat: "Y-m-d",
        maxDate: "today",
        defaultDate: "<?php echo $editData['graduation_date'] ?? ''; ?>"
    });

    document.querySelector('.manage-form').addEventListener('submit', function(e) {
        const cgpa = parseFloat(document.querySelector('input[name="grad-cgpa"]').value);
        if (cgpa < 2.0 || cgpa > 4.0) {
            e.preventDefault();
            alert('CGPA must be between 2.0 and 4.0');
            return false;
        }

        const gradId = document.querySelector('input[name="grad-id"]').value;
        const gradProgram = document.querySelector('select[name="grad-program"]').value;
        if (gradProgram === 'Regular' && !gradId.startsWith('UGR')) {
            e.preventDefault();
            alert("Regular program ID must start with 'UGR'!");
            return false;
        } else if (gradProgram === 'Weekend' && !gradId.startsWith('UGW')) {
            e.preventDefault();
            alert("Weekend program ID must start with 'UGW'!");
            return false;
        } else if (gradProgram === 'Summer' && !gradId.startsWith('UGS')) {
            e.preventDefault();
            alert("Summer program ID must start with 'UGS'!");
            return false;
        }
    });

    function toggleSelectAll(program) {
        const selectAllCheckbox = document.getElementById('selectAll' + program);
        const gradCheckboxes = document.querySelectorAll('.grad-checkbox-' + program.toLowerCase());
        const isChecked = selectAllCheckbox.checked;
        
        gradCheckboxes.forEach(checkbox => {
            checkbox.checked = !isChecked;
        });
        selectAllCheckbox.checked = !isChecked;
    }

    ['Regular', 'Weekend', 'Summer'].forEach(program => {
        document.getElementById('selectAll' + program).addEventListener('change', function() {
            const gradCheckboxes = document.querySelectorAll('.grad-checkbox-' + program.toLowerCase());
            gradCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    });
});