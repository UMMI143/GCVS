let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        const text = element.getAttribute('data-lang-' + currentLang);
        if (element.tagName === 'INPUT') {
            element.placeholder = text;
        } else if (element.tagName === 'SELECT' && element.options[0]) {
            Array.from(element.options).forEach(option => {
                const optText = option.getAttribute('data-lang-' + currentLang);
                if (optText) option.text = optText;
            });
        } else {
            element.innerHTML = text;
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    flatpickr(".flatpickr-input", {
        dateFormat: "Y-m-d",
        enableTime: false
    });
});