// students_list.js
let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        element.innerHTML = element.getAttribute('data-lang-' + currentLang);
    });
}

function toggleSelectAll(program) {
    const selectAllCheckbox = document.getElementById('selectAll' + program);
    const stuCheckboxes = document.querySelectorAll('.stu-checkbox-' + program.toLowerCase());
    const isChecked = selectAllCheckbox.checked;
    
    stuCheckboxes.forEach(checkbox => {
        checkbox.checked = !isChecked;
    });
    selectAllCheckbox.checked = !isChecked;
}

['Regular', 'Weekend', 'Summer'].forEach(program => {
    document.getElementById('selectAll' + program).addEventListener('change', function() {
        const stuCheckboxes = document.querySelectorAll('.stu-checkbox-' + program.toLowerCase());
        stuCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
});