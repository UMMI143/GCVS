let currentLang = 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'am' : 'en';
    document.querySelectorAll('[data-lang-' + currentLang + ']').forEach(element => {
        const text = element.getAttribute('data-lang-' + currentLang);
        if (element.tagName === 'INPUT') {
            element.placeholder = text;
        } else {
            element.textContent = text;
        }
    });
}