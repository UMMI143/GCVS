<?php
// Database Connection
$host = "localhost";
$dbname = "jinka_university";
$user = "root";
$pass = "";

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = filter_input(INPUT_POST, "id", FILTER_SANITIZE_STRING);
    $response = [];

    $stmt = $db->prepare("SELECT * FROM graduates WHERE id = ?");
    $stmt->execute([$id]);
    $graduate = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($graduate) {
        $response = ["status" => "success", "data" => $graduate];
    } else {
        $response = ["status" => "error", "message" => "No graduate record found for ID: $id | ለመለያ ቁጥር $id የተመራቂ መዝገብ አልተገኘም።"];
    }

    header("Content-Type: application/json");
    echo json_encode($response);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-en="Print Your Certificate" data-lang-am="የምስክር ወረቀትዎን ያትሙ">Print Your Certificate</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="assets/css/certificate.css">
    <script src="certificate.js" defer></script>
</head>
<body style="background: rgb(235, 216, 216);">
    <nav style="background: rgb(75, 145, 75);">
        <div class="logo">
            <img src="assets/img/logo.jpg" alt="Jinka University Logo">
            <span data-lang-en="Jinka University" data-lang-am="ጂንካ ዩኒቨርሲቲ" style="font-size: 72px;">Jinka University</span>
        </div>
        <div class="nav-controls">
            <button class="btn lang-btn" onclick="toggleLanguage()">En | አማ</button>
            <a href="index.html" class="btn back-btn" data-lang-en="Back to Home" data-lang-am="ወደ መነሻ ገፅ ተመለስ">Back to Home</a>
        </div>
    </nav>

    <div class="input-group">
        <input type="text" id="certificate-id" 
               data-lang-en="Enter Graduate ID" data-lang-am="የተመራቂ መለያ ቁጥር ያስገቡ" 
               placeholder="Enter Graduate ID">
        <button class="btn" onclick="fetchCertificate()" 
                data-lang-en="Fetch Certificate" data-lang-am="ምስክር ወረቀት ያምጡ">Fetch Certificate</button>
    </div>

    <div class="certificate-preview" id="certificate-preview"></div>

    <footer>

        <?php

    include 'footer.php';

        ?>

</footer>
</body>
</html>