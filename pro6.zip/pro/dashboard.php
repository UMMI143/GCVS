<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$autoloadPath = 'phpspreadsheet/vendor/autoload.php';
if (!file_exists($autoloadPath)) {
    die("Error: PhpSpreadsheet not installed. Run these commands: 1. cd C:\\xampp\\htdocs\\pro\\phpspreadsheet 2. composer require phpoffice/phpspreadsheet");
}

require $autoloadPath;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
require_once 'db_connect.php';

$db = (new Database())->connect();
$uploadDir = "uploads/";
if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

$message = "";
$searchResults = isset($_SESSION['searchResults']) ? $_SESSION['searchResults'] : [];
$userList = [];

// Fetch user list for admin
if ($_SESSION["role"] === "admin") {
    $stmt = $db->prepare("SELECT username, role, active FROM users WHERE username != ?");
    $stmt->execute([$_SESSION["user"]]);
    $userList = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Create Account
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["create_account"]) && $_SESSION["role"] === "admin") {
    $new_username = filter_input(INPUT_POST, "new_username", FILTER_SANITIZE_STRING);
    $new_password = filter_input(INPUT_POST, "new_password", FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, "confirm_password", FILTER_SANITIZE_STRING);
    $new_role = filter_input(INPUT_POST, "new_role", FILTER_SANITIZE_STRING);

    if ($new_password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        $stmt = $db->prepare("INSERT INTO users (username, password, role, active) VALUES (?, ?, ?, 1)");
        try {
            $stmt->execute([$new_username, $new_password, $new_role]);
            $message = "Account created successfully!";
        } catch (PDOException $e) {
            $message = "Error creating account: " . $e->getMessage();
        }
    }
}

// Change Password
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["change_password"])) {
    $new_password = filter_input(INPUT_POST, "new_password", FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, "confirm_password", FILTER_SANITIZE_STRING);

    if ($new_password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = ?");
        try {
            $stmt->execute([$new_password, $_SESSION["user"]]);
            $message = "Password changed successfully!";
        } catch (PDOException $e) {
            $message = "Error changing password: " . $e->getMessage();
        }
    }
}

// Deactivate Account
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["deactivate_account"]) && $_SESSION["role"] === "admin") {
    $username_to_deactivate = filter_input(INPUT_POST, "username_to_deactivate", FILTER_SANITIZE_STRING);
    if ($username_to_deactivate !== $_SESSION["user"]) {
        $stmt = $db->prepare("UPDATE users SET active = 0 WHERE username = ?");
        try {
            $stmt->execute([$username_to_deactivate]);
            $message = "Account '$username_to_deactivate' deactivated successfully!";
        } catch (PDOException $e) {
            $message = "Error deactivating account: " . $e->getMessage();
        }
    } else {
        $message = "You cannot deactivate your own account!";
    }
}

// Activate Account
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["activate_account"]) && $_SESSION["role"] === "admin") {
    $username_to_activate = filter_input(INPUT_POST, "username_to_activate", FILTER_SANITIZE_STRING);
    if ($username_to_activate !== $_SESSION["user"]) {
        $stmt = $db->prepare("UPDATE users SET active = 1 WHERE username = ?");
        try {
            $stmt->execute([$username_to_activate]);
            $message = "Account '$username_to_activate' activated successfully!";
        } catch (PDOException $e) {
            $message = "Error activating account: " . $e->getMessage();
        }
    } else {
        $message = "Your account is already active!";
    }
}

// Delete Account
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_account"]) && $_SESSION["role"] === "admin") {
    $username_to_delete = filter_input(INPUT_POST, "username_to_delete", FILTER_SANITIZE_STRING);
    if ($username_to_delete !== $_SESSION["user"]) {
        $stmt = $db->prepare("DELETE FROM users WHERE username = ?");
        try {
            $stmt->execute([$username_to_delete]);
            $message = "Account '$username_to_delete' deleted successfully!";
        } catch (PDOException $e) {
            $message = "Error deleting account: " . $e->getMessage();
        }
    } else {
        $message = "You cannot delete your own account!";
    }
}

// Search Students/Graduates
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["search"])) {
    $qualification = filter_input(INPUT_POST, "qualification", FILTER_SANITIZE_STRING);
    $department = filter_input(INPUT_POST, "department", FILTER_SANITIZE_STRING);
    $gender = filter_input(INPUT_POST, "gender", FILTER_SANITIZE_STRING);
    $cost_share = filter_input(INPUT_POST, "cost_share", FILTER_SANITIZE_STRING);
    $program = filter_input(INPUT_POST, "program", FILTER_SANITIZE_STRING);
    $type = filter_input(INPUT_POST, "type", FILTER_SANITIZE_STRING);
    
    try {
        $query = "
            SELECT id, name, gpa AS grade, NULL AS qualification, department, gender, 
                   entry_date AS date_field, cost_share, photo, program, 'Student' AS type 
            FROM students 
            WHERE 1=1
            " . ($department !== 'all' ? "AND department = ?" : "") . "
            " . ($gender !== 'all' ? "AND gender = ?" : "") . "
            " . ($cost_share !== 'all' ? "AND cost_share = ?" : "") . "
            " . ($program !== 'all' ? "AND program = ?" : "") . "
            " . ($type === 'current student' ? "" : "AND 1=0") . "
            UNION
            SELECT id, name, cgpa AS grade, qualification, department, gender, 
                   graduation_date AS date_field, cost_share, photo, program, 'Graduate' AS type 
            FROM graduates 
            WHERE 1=1
            " . ($qualification !== 'all' ? "AND qualification = ?" : "") . "
            " . ($department !== 'all' ? "AND department = ?" : "") . "
            " . ($gender !== 'all' ? "AND gender = ?" : "") . "
            " . ($cost_share !== 'all' ? "AND cost_share = ?" : "") . "
            " . ($program !== 'all' ? "AND program = ?" : "") . "
            " . ($type === 'graduate' ? "" : "AND 1=0") . "
            ORDER BY name";
            
        $params = [];
        if ($department !== 'all') $params[] = $department;
        if ($gender !== 'all') $params[] = $gender;
        if ($cost_share !== 'all') $params[] = $cost_share;
        if ($program !== 'all') $params[] = $program;
        if ($qualification !== 'all') $params[] = $qualification;
        if ($department !== 'all') $params[] = $department;
        if ($gender !== 'all') $params[] = $gender;
        if ($cost_share !== 'all') $params[] = $cost_share;
        if ($program !== 'all') $params[] = $program;
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $_SESSION['searchResults'] = $searchResults; // Store in session for export
        
        if (empty($searchResults)) {
            $message = "No results found for the specified criteria";
        }
    } catch (PDOException $e) {
        $message = "Database error: " . $e->getMessage();
    }
}

// Export Search Results to Excel
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["export_excel"])) {
    if (empty($searchResults)) {
        $message = "No search results available to export. Please perform a search first.";
    } else {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        
        $headers = ['ID', 'Name', 'Grade', 'Qualification', 'Department', 'Gender', 'Date', 'Cost Share', 'Program', 'Type'];
        $column = 'A';
        foreach ($headers as $header) {
            $sheet->setCellValue($column . '1', $header);
            $column++;
        }
        
        $sheet->getStyle('A1:J1')->getFont()->setBold(true);
        $sheet->getStyle('A1:J1')->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()->setARGB('FF1C81EC');
        
        $row = 2;
        foreach ($searchResults as $result) {
            $sheet->setCellValue('A' . $row, $result['id']);
            $sheet->setCellValue('B' . $row, $result['name']);
            $sheet->setCellValue('C' . $row, $result['grade']);
            $sheet->setCellValue('D' . $row, $result['qualification'] ?? 'N/A');
            $sheet->setCellValue('E' . $row, $result['department']);
            $sheet->setCellValue('F' . $row, $result['gender']);
            $sheet->setCellValue('G' . $row, $result['date_field']);
            $sheet->setCellValue('H' . $row, $result['cost_share']);
            $sheet->setCellValue('I' . $row, $result['program']);
            $sheet->setCellValue('J' . $row, $result['type']);
            $row++;
        }
        
        foreach (range('A', 'J') as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="search_results_' . date('Ymd_His') . '.xlsx"');
        header('Cache-Control: max-age=0');
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
}

// Export Graduates List to Excel
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["export_graduates"])) {
    try {
        $stmt = $db->query("SELECT id, name, cgpa AS grade, qualification, department, gender, graduation_date AS date_field, cost_share, program, verification_code 
                            FROM graduates 
                            ORDER BY name");
        $graduates = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($graduates)) {
            $message = "No graduates found to export.";
        } else {
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            $headers = ['ID', 'Name', 'CGPA', 'Qualification', 'Department', 'Gender', 'Graduation Date', 'Cost Share', 'Program', 'Verification Code'];
            $column = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($column . '1', $header);
                $column++;
            }

            $sheet->getStyle('A1:J1')->getFont()->setBold(true);
            $sheet->getStyle('A1:J1')->getFill()
                ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                ->getStartColor()->setARGB('FF1C81EC');

            $row = 2;
            foreach ($graduates as $graduate) {
                $sheet->setCellValue('A' . $row, $graduate['id']);
                $sheet->setCellValue('B' . $row, $graduate['name']);
                $sheet->setCellValue('C' . $row, $graduate['grade']);
                $sheet->setCellValue('D' . $row, $graduate['qualification']);
                $sheet->setCellValue('E' . $row, $graduate['department']);
                $sheet->setCellValue('F' . $row, $graduate['gender']);
                $sheet->setCellValue('G' . $row, $graduate['date_field']);
                $sheet->setCellValue('H' . $row, $graduate['cost_share']);
                $sheet->setCellValue('I' . $row, $graduate['program']);
                $sheet->setCellValue('J' . $row, $graduate['verification_code']);
                $row++;
            }

            foreach (range('A', 'J') as $columnID) {
                $sheet->getColumnDimension($columnID)->setAutoSize(true);
            }

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="graduates_list_' . date('Ymd_His') . '.xlsx"');
            header('Cache-Control: max-age=0');

            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        }
    } catch (PDOException $e) {
        $message = "Error exporting graduates: " . $e->getMessage();
    }
}

// Export Students List to Excel
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["export_students"])) {
    try {
        $stmt = $db->query("SELECT id, name, gpa AS grade, department, gender, entry_date AS date_field, cost_share, program 
                            FROM students 
                            ORDER BY name");
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($students)) {
            $message = "No students found to export.";
        } else {
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            $headers = ['ID', 'Name', 'GPA', 'Department', 'Gender', 'Entry Date', 'Cost Share', 'Program'];
            $column = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($column . '1', $header);
                $column++;
            }

            $sheet->getStyle('A1:H1')->getFont()->setBold(true);
            $sheet->getStyle('A1:H1')->getFill()
                ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                ->getStartColor()->setARGB('FF1C81EC');

            $row = 2;
            foreach ($students as $student) {
                $sheet->setCellValue('A' . $row, $student['id']);
                $sheet->setCellValue('B' . $row, $student['name']);
                $sheet->setCellValue('C' . $row, $student['grade']);
                $sheet->setCellValue('D' . $row, $student['department']);
                $sheet->setCellValue('E' . $row, $student['gender']);
                $sheet->setCellValue('F' . $row, $student['date_field']);
                $sheet->setCellValue('G' . $row, $student['cost_share']);
                $sheet->setCellValue('H' . $row, $student['program']);
                $row++;
            }

            foreach (range('A', 'H') as $columnID) {
                $sheet->getColumnDimension($columnID)->setAutoSize(true);
            }

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="students_list_' . date('Ymd_His') . '.xlsx"');
            header('Cache-Control: max-age=0');

            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        }
    } catch (PDOException $e) {
        $message = "Error exporting students: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-en="Jinka University - Admin Dashboard" data-lang-am="ጂንካ ዩኒቨርሲቲ - የአስተዳዳሪ ዳሽቦርድ">Jinka University - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="assets/js/dashboard.js" defer></script>
</head>
<body style="background: rgb(235, 216, 235);">
<header>
    <h1 data-lang-en="Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?>!" data-lang-am="እንኳን ደህና መጡ፣ <?php echo htmlspecialchars($_SESSION["user"]); ?>!"> Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?>! </h1>
    <div class="nav-controls">
        <button class="btn lang-btn" onclick="toggleLanguage()">En | አማ</button>
        <a href="logout.php" class="btn logout-btn" data-lang-en="Logout" data-lang-am="ውጣ">Logout</a>
    </div>
</header>
<main>
    <?php if ($_SESSION["role"] === "admin"): ?>
        <div class="admin-controls" style="background: rgb(200, 200, 200);">
            <h3 data-lang-en="Admin Controls" data-lang-am="የአስተዳዳሪ መቆጣጠሪያ">Admin Controls</h3>
            <form method="post" class="manage-form">
                <input type="text" name="new_username" placeholder="New Username" required>
                <input type="password" name="new_password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <select name="new_role" required>
                    <option value="admin">Admin</option>
                    <option value="registrar">Registrar</option>
                </select>
                <button type="submit" name="create_account" class="btn" data-lang-en="Create Account" data-lang-am="መለያ ፍጠር">Create Account</button>
            </form>
            
            <?php if (!empty($userList)): ?>
                <table class="user-table">
                    <thead>
                        <tr>
                            <th data-lang-en="Username" data-lang-am="የተጠቃሚ ስም">Username</th>
                            <th data-lang-en="Role" data-lang-am="ሚና">Role</th>
                            <th data-lang-en="Status" data-lang-am="ሁኔታ">Status</th>
                            <th data-lang-en="Actions" data-lang-am="ተግባሮች">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($userList as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user["username"]); ?></td>
                                <td><?php echo htmlspecialchars($user["role"]); ?></td>
                                <td><?php echo $user["active"] ? 'Active' : 'Inactive'; ?></td>
                                <td>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="username_to_deactivate" value="<?php echo htmlspecialchars($user["username"]); ?>">
                                        <button type="submit" name="deactivate_account" class="btn deactivate-btn" 
                                                data-lang-en="Deactivate" data-lang-am="አቦዝን" <?php echo $user["active"] ? '' : 'disabled'; ?>>Deactivate</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="username_to_activate" value="<?php echo htmlspecialchars($user["username"]); ?>">
                                        <button type="submit" name="activate_account" class="btn activate-btn" 
                                                data-lang-en="Activate" data-lang-am="አግብር" <?php echo !$user["active"] ? '' : 'disabled'; ?>>Activate</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="username_to_delete" value="<?php echo htmlspecialchars($user["username"]); ?>">
                                        <button type="submit" name="delete_account" class="btn delete-btn" 
                                                data-lang-en="Delete" data-lang-am="ሰርዝ" onclick="return confirm('Are you sure you want to delete this account?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="password-change" style="background: rgb(200, 200, 200);">
        <h3 data-lang-en="Change Password" data-lang-am="የይለፍ ቃል ቀይር">Change Password</h3>
        <form method="post" class="manage-form">
            <input type="password" name="new_password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit" name="change_password" class="btn" data-lang-en="Change Password" data-lang-am="የይለፍ ቃል ቀይር">Change Password</button>
        </form>
    </div>

    <?php if ($message): ?>
        <div class="<?php echo strpos($message, 'Error') === false ? 'message' : 'error'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="search-container" style="background: rgb(200, 200, 200);">
        <h2 data-lang-en="Student Information" data-lang-am="የተማሪ መረጃ">Student Information</h2>
        <form class="search-form" method="post">
            <select name="qualification" required>
                <option value="all" data-lang-en="All Qualifications" data-lang-am="ሁሉም ማስረጃዎች">All Qualifications</option>
                <option value="bsc" data-lang-en="BSc" data-lang-am="ቢኤስሲ">BSc</option>
                <option value="msc" data-lang-en="MSc" data-lang-am="ኤምኤስሲ">MSc</option>
            </select>
            <select name="department" required>
                <option value="all" data-lang-en="All Departments" data-lang-am="ሁሉም ዲፓርትመንቶች">All Departments</option>
                <option value="Agricultural Economics">Agricultural Economics</option>
                <option value="Animal Science">Animal Science</option>
                <option value="Natural Resource Management">Natural Resource Management</option>
                <option value="Plant Science">Plant Science</option>
                <option value="Biology">Biology</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Physics">Physics</option>
                <option value="English Language and Literature">English Language and Literature</option>
                <option value="Geography">Geography</option>
                <option value="History and Heritage Management">History and Heritage Management</option>
                <option value="Accounting and Finance">Accounting and Finance</option>
                <option value="Economics">Economics</option>
                <option value="Management">Management</option>
                <option value="Health Officer">Health Officer</option>
                <option value="Midwife Nurse">Midwife Nurse</option>
                <option value="Nursing">Nursing</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Anthropology">Anthropology</option>
                <option value="HPE">HPE</option>
                <option value="AgriBusiness">AgriBusiness</option>
                <option value="Law">Law</option>
            </select>
            <select name="gender" required>
                <option value="all" data-lang-en="All Genders" data-lang-am="ሁሉም ፆታዎች">All Genders</option>
                <option value="male" data-lang-en="Male" data-lang-am="ወንድ">Male</option>
                <option value="female" data-lang-en="Female" data-lang-am="ሴት">Female</option>
            </select>
            <select name="cost_share" required>
                <option value="all" data-lang-en="All Cost Shares" data-lang-am="ሁሉም ወጪ መጋራቶች">All Cost Shares</option>
                <option value="paid" data-lang-en="Paid" data-lang-am="የተከፈለ">Paid</option>
                <option value="unpaid" data-lang-en="Unpaid" data-lang-am="ያልተከፈለ">Unpaid</option>
            </select>
            <select name="program" required>
                <option value="all" data-lang-en="All Programs" data-lang-am="ሁሉም ፕሮግራሞች">All Programs</option>
                <option value="regular" data-lang-en="Regular" data-lang-am="መደበኛ">Regular</option>
                <option value="weekend" data-lang-en="Weekend" data-lang-am="ሳምንታዊ">Weekend</option>
                <option value="summer" data-lang-en="Summer" data-lang-am="በጋ">Summer</option>
            </select>
            <select name="type" required>
                <option value="all" data-lang-en="All Types" data-lang-am="ሁሉም አይነቶች">All Types</option>
                <option value="graduate" data-lang-en="Graduate" data-lang-am="ተመራቂ">Graduate</option>
                <option value="current student" data-lang-en="Current Student" data-lang-am="አሁን ያለ ተማሪ">Current Student</option>
            </select>
            <button type="submit" name="search" data-lang-en="Search" data-lang-am="ፈልግ">Search</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <form method="post" class="export-graduates-form" style="display: inline-block; margin-right: 10px;">
                <button type="submit" name="export_graduates" class="btn export-graduates-btn" 
                        data-lang-en="Export Graduates List" data-lang-am="የተመራቂዎች ዝርዝር ላክ">Export Graduates List</button>
            </form>
            <form method="post" class="export-students-form" style="display: inline-block; margin-left: 10px;">
                <button type="submit" name="export_students" class="btn export-students-btn" 
                        data-lang-en="Export Students List" data-lang-am="የተማሪዎች ዝርዝር ላክ">Export Students List</button>
            </form>
        </div>

        <?php if (!empty($searchResults)): ?>
            <form method="post" class="export-form" style="text-align: center;">
                <button type="submit" name="export_excel" class="btn export-btn" 
                        data-lang-en="Export Search to Excel" 
                        data-lang-am="ፍለጋን ወደ ኤክሴል ላክ">Export Search to Excel</button>
            </form>
            <table class="results-table">
                <thead>
                    <tr>
                        <th data-lang-en="ID" data-lang-am="መለያ">ID</th>
                        <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                        <th data-lang-en="Grade" data-lang-am="ውጤት">Grade</th>
                        <th data-lang-en="Qualification" data-lang-am="ማስረጃ">Qualification</th>
                        <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                        <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                        <th data-lang-en="Entry/Graduation Date" data-lang-am="የመግቢያ/መመረቂያ ቀን">Entry/Graduation Date</th>
                        <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራቍ">Cost Share</th>
                        <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                        <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                        <th data-lang-en="Type" data-lang-am="አይነት">Type</th>
                        <th data-lang-en="Action" data-lang-am="ተግባር">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($searchResults as $result): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($result["id"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["name"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["grade"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["qualification"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($result["department"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["gender"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["date_field"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["cost_share"] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($result["program"] ?? ''); ?></td>
                            <td><?php echo $result["photo"] ? "<img src='uploads/" . htmlspecialchars($result["photo"]) . "' alt='Photo' width='50'>" : ''; ?></td>
                            <td><?php echo htmlspecialchars($result["type"] ?? ''); ?></td>
                            <td>
                                <a href="<?php echo $result["type"] === 'Student' ? 'students_list.php' : 'graduates_list.php'; ?>?edit_id=<?php echo urlencode($result["id"]); ?>" 
                                   class="btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="links">
        <a href="graduates_list.php" data-lang-en="Add/View Graduates" data-lang-am="ተመራቂዎችን ጨምር/ተመልከት">Add/View Graduates</a>
        <a href="students_list.php" data-lang-en="Add/View Students" data-lang-am="ተማሪዎችን ጨምር/ተመልከት">Add/View Students</a>
    </div>
</main>

<footer>
<?php

include 'footer.php';

    ?>
</footer>
</body>
</html>