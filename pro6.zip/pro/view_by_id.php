<?php
require_once 'db_connect.php';
$db = new Database();
$pdo = $db->connect();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = filter_input(INPUT_POST, "id", FILTER_SANITIZE_STRING);
    $response = [];

    try {
        $stmt = $pdo->prepare("SELECT * FROM graduates WHERE id = ?");
        $stmt->execute([$id]);
        $graduate = $stmt->fetch(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($graduate) {
            $response = ["status" => "success", "type" => "graduate", "data" => $graduate];
        } elseif ($student) {
            $response = ["status" => "success", "type" => "student", "data" => $student];
        } else {
            $response = ["status" => "error", "message" => "No record found for ID: $id"];
        }
    } catch (PDOException $e) {
        $response = ["status" => "error", "message" => "Database error: " . $e->getMessage()];
    }

    header("Content-Type: application/json");
    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jinka University Verification</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/view_by_id.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Jinka University Logo" width="75" height="75">
                <span data-lang-en="Jinka University" data-lang-am="ጂንካ ዩኒቨርሲቲ">Jinka University</span>
            </div>
            <div class="nav-controls">
                <button class="btn lang-btn" onclick="toggleLanguage()">En | አማ</button>
            </div>
        </nav>
        <div class="hero-content">
            <h1 data-lang-en="Credential Verification Made Simple" data-lang-am="የምስክር ወረቀት ማረጋገጫ ቀላል ተደርጓል">Credential Verification Made Simple</h1>
            <p data-lang-en="Verify graduate and student details instantly with AI-powered precision." 
               data-lang-am="የተመራቂዎችን እና የተማሪዎችን ዝርዝሮች በኤአይ የተጎላበተ ትክክለኛነት በፍጥነት አረጋግጥ።">
                Verify graduate and student details instantly with AI-powered precision.
            </p>
            <div class="verification-box">
                <input type="text" id="student-id" 
                       data-lang-en="Enter Student ID" data-lang-am="የተማሪ መለያ አስገባ" 
                       placeholder="Enter Student ID">
                <button class="btn verify-btn" onclick="verifyStudent()" 
                        data-lang-en="View Now" data-lang-am="አሁን ተመልከት">View Now</button>
            </div>
            <div class="result-preview" id="verification-result"></div>
        </div>
        <a href="index.html" class="btn back-btn" data-lang-en="Back to Home" data-lang-am="ወደ መነሻ ተመለስ">Back to Home</a>
    </header>

    <footer>
        <div class="footer-content">
        <?php

include 'footer.php';

    ?>
</div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="view_by_id.js"></script>
</body>
</html>