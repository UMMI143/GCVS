<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION["user"])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$host = "localhost";
$dbname = "jinka_university";
$username = "root"; // Replace with your MySQL username
$password = "";     // Replace with your MySQL password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);
$action = $_GET["action"] ?? $input["action"] ?? "";

// Handle file uploads
function uploadPhoto($id, $file) {
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    $ext = pathinfo($file["name"], PATHINFO_EXTENSION);
    $filePath = $uploadDir . $id . "." . $ext;
    if (move_uploaded_file($file["tmp_name"], $filePath)) {
        return $filePath;
    }
    return null;
}

switch ($action) {
    case "get_graduates":
        $stmt = $pdo->query("SELECT * FROM graduates");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case "get_students":
        $stmt = $pdo->query("SELECT * FROM students");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case "add_graduate":
        $data = $input["data"];
        if (empty($data["id"]) || !preg_match('/^JU\d{3}$/', $data["id"])) {
            echo json_encode(["error" => "Invalid Graduate ID"]);
            break;
        }
        $photoPath = uploadPhoto($data["id"], $_FILES["photo"]);
        if (!$photoPath) {
            echo json_encode(["error" => "Photo upload failed"]);
            break;
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO graduates (id, name, cgpa, exit_exam, department, gender, year_of_graduation, cost_share_status, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$data["id"], $data["name"], $data["cgpa"], $data["exit_exam"], $data["department"], $data["gender"], $data["year_of_graduation"], $data["cost_share_status"], $photoPath]);
            echo json_encode(["success" => true]);
        } catch (PDOException $e) {
            echo json_encode(["error" => "Graduate ID already exists or invalid data"]);
        }
        break;

    case "add_student":
        $data = $input["data"];
        if (empty($data["id"]) || !preg_match('/^JU\d{3}$/', $data["id"])) {
            echo json_encode(["error" => "Invalid Student ID"]);
            break;
        }
        $photoPath = uploadPhoto($data["id"], $_FILES["photo"]);
        if (!$photoPath) {
            echo json_encode(["error" => "Photo upload failed"]);
            break;
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO students (id, name, current_gpa, department, gender, year_of_entering, cost_share_status, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$data["id"], $data["name"], $data["current_gpa"], $data["department"], $data["gender"], $data["year_of_entering"], $data["cost_share_status"], $photoPath]);
            echo json_encode(["success" => true]);
        } catch (PDOException $e) {
            echo json_encode(["error" => "Student ID already exists or invalid data"]);
        }
        break;

    case "update_graduate":
        $id = $input["id"];
        $data = $input["data"];
        $photoPath = isset($_FILES["photo"]) ? uploadPhoto($id, $_FILES["photo"]) : null;
        $query = "UPDATE graduates SET name = ?, cgpa = ?, exit_exam = ?, department = ?, gender = ?, year_of_graduation = ?, cost_share_status = ?";
        $params = [$data["name"], $data["cgpa"], $data["exit_exam"], $data["department"], $data["gender"], $data["year_of_graduation"], $data["cost_share_status"]];
        if ($photoPath) {
            $query .= ", photo = ?";
            $params[] = $photoPath;
        }
        $query .= " WHERE id = ?";
        $params[] = $id;
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        echo json_encode(["success" => $stmt->rowCount() > 0]);
        break;

    case "update_student":
        $id = $input["id"];
        $data = $input["data"];
        $photoPath = isset($_FILES["photo"]) ? uploadPhoto($id, $_FILES["photo"]) : null;
        $query = "UPDATE students SET name = ?, current_gpa = ?, department = ?, gender = ?, year_of_entering = ?, cost_share_status = ?";
        $params = [$data["name"], $data["current_gpa"], $data["department"], $data["gender"], $data["year_of_entering"], $data["cost_share_status"]];
        if ($photoPath) {
            $query .= ", photo = ?";
            $params[] = $photoPath;
        }
        $query .= " WHERE id = ?";
        $params[] = $id;
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        echo json_encode(["success" => $stmt->rowCount() > 0]);
        break;

    case "delete_graduate":
        $id = $input["id"];
        $stmt = $pdo->prepare("DELETE FROM graduates WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["success" => $stmt->rowCount() > 0]);
        break;

    case "delete_student":
        $id = $input["id"];
        $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["success" => $stmt->rowCount() > 0]);
        break;

    default:
        echo json_encode(["error" => "Invalid action"]);
}
?>