<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

// Check if Composer autoloader exists
$autoloadPath = 'phpspreadsheet/vendor/autoload.php';
if (!file_exists($autoloadPath)) {
    die("Error: Composer autoloader not found at '$autoloadPath'. Please run 'composer require phpoffice/phpspreadsheet' in 'C:\\xampp\\htdocs\\pro\\phpspreadsheet'.");
}
require $autoloadPath;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;

// Database connection
$host = "localhost";
$dbname = "jinka_university";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Directory for photo uploads
$uploadDir = "uploads/";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$message = "";
$editData = null;
$currentDate = date('Y-m-d'); // Current date: March 19, 2025

// Function to generate verification code for graduates
function generateVerificationCode($pdo) {
    $stmt = $pdo->query("SELECT MAX(CAST(SUBSTRING(verification_code, 4) AS UNSIGNED)) as max_code FROM graduates");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $nextNum = ($result['max_code'] ?? 0) + 1;
    return "JkU" . str_pad($nextNum, 3, "0", STR_PAD_LEFT);
}

// Function to generate student ID based on program
function generateStudentID($pdo, $program) {
    $prefix = '';
    switch (strtolower($program)) {
        case 'regular':
            $prefix = 'UGR';
            break;
        case 'weekend':
            $prefix = 'UGW';
            break;
        case 'summer':
            $prefix = 'UGS';
            break;
        default:
            throw new Exception("Invalid program type!");
    }
    
    $stmt = $pdo->prepare("SELECT MAX(CAST(SUBSTRING(id, 4) AS UNSIGNED)) as max_num 
                          FROM students 
                          WHERE id LIKE ?");
    $stmt->execute(["$prefix%"]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $nextNum = ($result['max_num'] ?? 0) + 1;
    return $prefix . str_pad($nextNum, 3, "0", STR_PAD_LEFT);
}

// Check and transfer graduated students
$stmt = $pdo->query("SELECT * FROM students WHERE graduation_date = '$currentDate'");
$graduatingStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($graduatingStudents as $student) {
    $verificationCode = generateVerificationCode($pdo);
    $stmt = $pdo->prepare("INSERT INTO graduates (id, name, cgpa, department, gender, graduation_date, cost_share, photo, program, verification_code) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$student['id'], $student['name'], $student['gpa'], $student['department'], $student['gender'], $student['graduation_date'], 
                    $student['cost_share'], $student['photo'], $student['program'], $verificationCode]);
    
    $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
    $stmt->execute([$student['id']]);
    
    $message .= "Student {$student['id']} transferred to graduates with verification code: $verificationCode | ";
}

// Fetch student data for editing
if (isset($_GET["edit_id"])) {
    $edit_id = filter_input(INPUT_GET, "edit_id", FILTER_SANITIZE_STRING);
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editData = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$editData) {
        $message = "Student not found! | ተማሪ አልተገኘም!";
    }
}

// Add student manually
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_stu"])) {
    try {
        $stu_name = filter_input(INPUT_POST, "stu-name", FILTER_SANITIZE_STRING);
        $stu_gpa = filter_input(INPUT_POST, "stu-gpa", FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $stu_dept = filter_input(INPUT_POST, "stu-dept", FILTER_SANITIZE_STRING);
        $stu_gender = filter_input(INPUT_POST, "stu-gender", FILTER_SANITIZE_STRING);
        $stu_entry_date = filter_input(INPUT_POST, "stu-entry-date", FILTER_SANITIZE_STRING);
        $stu_grad_date = filter_input(INPUT_POST, "stu-grad-date", FILTER_SANITIZE_STRING);
        $stu_cost_share = filter_input(INPUT_POST, "stu-cost-share", FILTER_SANITIZE_STRING);
        $stu_program = filter_input(INPUT_POST, "stu-program", FILTER_SANITIZE_STRING);

        if (empty($stu_name) || empty($stu_gpa) || empty($stu_dept) || 
            empty($stu_gender) || empty($stu_entry_date) || empty($stu_grad_date) || 
            empty($stu_cost_share) || empty($stu_program)) {
            throw new Exception("All fields are required!");
        }

        if ($stu_gpa < 0 || $stu_gpa > 4) {
            throw new Exception("GPA must be between 0 and 4!");
        }

        $stu_id = generateStudentID($pdo, $stu_program);

        $stu_photo = "";
        if (!empty($_FILES["stu-photo"]["name"])) {
            $fileExt = strtolower(pathinfo($_FILES["stu-photo"]["name"], PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($fileExt, $allowedExt)) {
                throw new Exception("Invalid file type! Only JPG, JPEG, PNG, and GIF allowed.");
            }
            $stu_photo = uniqid() . '.' . $fileExt;
            $target = $uploadDir . $stu_photo;
            if (!move_uploaded_file($_FILES["stu-photo"]["tmp_name"], $target)) {
                throw new Exception("Failed to upload photo.");
            }
        }

        $stmt = $pdo->prepare("INSERT INTO students (id, name, gpa, department, gender, entry_date, graduation_date, cost_share, photo, program) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$stu_id, $stu_name, $stu_gpa, $stu_dept, $stu_gender, $stu_entry_date, $stu_grad_date, $stu_cost_share, $stu_photo, $stu_program]);
        $message = "Student added successfully with ID: $stu_id! | ተማሪ በተሳካ ሁኔታ ተጨምሯል በመለያ: $stu_id!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Update student
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_stu"])) {
    try {
        $stu_id = filter_input(INPUT_POST, "stu-id", FILTER_SANITIZE_STRING);
        $stu_name = filter_input(INPUT_POST, "stu-name", FILTER_SANITIZE_STRING);
        $stu_gpa = filter_input(INPUT_POST, "stu-gpa", FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $stu_dept = filter_input(INPUT_POST, "stu-dept", FILTER_SANITIZE_STRING);
        $stu_gender = filter_input(INPUT_POST, "stu-gender", FILTER_SANITIZE_STRING);
        $stu_entry_date = filter_input(INPUT_POST, "stu-entry-date", FILTER_SANITIZE_STRING);
        $stu_grad_date = filter_input(INPUT_POST, "stu-grad-date", FILTER_SANITIZE_STRING);
        $stu_cost_share = filter_input(INPUT_POST, "stu-cost-share", FILTER_SANITIZE_STRING);
        $stu_program = filter_input(INPUT_POST, "stu-program", FILTER_SANITIZE_STRING);

        if (empty($stu_id) || empty($stu_name) || empty($stu_gpa) || empty($stu_dept) || 
            empty($stu_gender) || empty($stu_entry_date) || empty($stu_grad_date) || empty($stu_cost_share) || empty($stu_program)) {
            throw new Exception("All fields are required!");
        }

        if ($stu_gpa < 0 || $stu_gpa > 4) {
            throw new Exception("GPA must be between 0 and 4!");
        }

        // Validate ID prefix based on program
        if ($stu_program === "Regular" && !preg_match("/^UGR/", $stu_id)) {
            throw new Exception("Regular program ID must start with 'UGR'!");
        } elseif ($stu_program === "Weekend" && !preg_match("/^UGW/", $stu_id)) {
            throw new Exception("Weekend program ID must start with 'UGW'!");
        } elseif ($stu_program === "Summer" && !preg_match("/^UGS/", $stu_id)) {
            throw new Exception("Summer program ID must start with 'UGS'!");
        }

        $stu_photo = filter_input(INPUT_POST, "existing-photo", FILTER_SANITIZE_STRING);
        if (!empty($_FILES["stu-photo"]["name"])) {
            $fileExt = strtolower(pathinfo($_FILES["stu-photo"]["name"], PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($fileExt, $allowedExt)) {
                throw new Exception("Invalid file type! Only JPG, JPEG, PNG, and GIF allowed.");
            }
            $stu_photo = uniqid() . '.' . $fileExt;
            $target = $uploadDir . $stu_photo;
            if (!move_uploaded_file($_FILES["stu-photo"]["tmp_name"], $target)) {
                throw new Exception("Failed to upload new photo.");
            }
            if (!empty($_POST["existing-photo"]) && file_exists($uploadDir . $_POST["existing-photo"])) {
                unlink($uploadDir . $_POST["existing-photo"]);
            }
        }

        $stmt = $pdo->prepare("UPDATE students SET name=?, gpa=?, department=?, gender=?, entry_date=?, graduation_date=?, cost_share=?, photo=?, program=? WHERE id=?");
        $stmt->execute([$stu_name, $stu_gpa, $stu_dept, $stu_gender, $stu_entry_date, $stu_grad_date, $stu_cost_share, $stu_photo, $stu_program, $stu_id]);
        $message = "Student updated successfully! | ተማሪ በተሳካ ሁኔታ ተዘምኗል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Delete single student
if (isset($_GET["delete_stu"])) {
    try {
        $stu_id = filter_input(INPUT_GET, "delete_stu", FILTER_SANITIZE_STRING);
        $stmt = $pdo->prepare("SELECT photo FROM students WHERE id = ?");
        $stmt->execute([$stu_id]);
        $photo = $stmt->fetchColumn();

        $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $stmt->execute([$stu_id]);

        if ($photo && file_exists($uploadDir . $photo)) {
            unlink($uploadDir . $photo);
        }

        $message = "Student deleted successfully! | ተማሪ በተሳካ ሁኔታ ተሰርዟል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Delete multiple students
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_selected"])) {
    try {
        if (!isset($_POST["selected_students"]) || empty($_POST["selected_students"])) {
            throw new Exception("No students selected for deletion!");
        }

        $selectedIds = $_POST["selected_students"];
        $placeholders = str_repeat('?,', count($selectedIds) - 1) . '?';

        $stmt = $pdo->prepare("SELECT id, photo FROM students WHERE id IN ($placeholders)");
        $stmt->execute($selectedIds);
        $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("DELETE FROM students WHERE id IN ($placeholders)");
        $stmt->execute($selectedIds);

        foreach ($photos as $photo) {
            if ($photo['photo'] && file_exists($uploadDir . $photo['photo'])) {
                unlink($uploadDir . $photo['photo']);
            }
        }

        $message = "Selected students deleted successfully! | ተመረጡት ተማሪዎች በተሳካ ሁኔታ ተሰርዘዋል!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage() . " | ስህተት: " . $e->getMessage();
    }
}

// Export to Excel for specific program
if (isset($_GET["export_program"])) {
    try {
        $program = filter_input(INPUT_GET, "export_program", FILTER_SANITIZE_STRING);
        if (!in_array($program, ['Regular', 'Weekend', 'Summer'])) {
            throw new Exception("Invalid program specified!");
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["Student ID", "Name", "GPA", "Department", "Gender", "Entry Date", "Graduation Date", "Cost Share", "Program"];
        $sheet->fromArray($headers, NULL, 'A1');

        $stmt = $pdo->prepare("SELECT id, name, gpa, department, gender, entry_date, graduation_date, cost_share, program FROM students WHERE program = ? ORDER BY id");
        $stmt->execute([$program]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $rowNum = 2;
        foreach ($students as $row) {
            $sheet->fromArray(array_values($row), NULL, 'A' . $rowNum);
            $rowNum++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = strtolower($program) . "_students_export_" . date('Ymd_His') . ".xlsx";
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
        exit;
    } catch (Exception $e) {
        $message = "Error exporting $program to Excel: " . $e->getMessage();
    }
}

// Import from Excel for specific program
if ($_SERVER["REQUEST_METHOD"] === "POST" && (isset($_FILES["import_file_regular"]) || isset($_FILES["import_file_weekend"]) || isset($_FILES["import_file_summer"]))) {
    try {
        $program = '';
        if (isset($_FILES["import_file_regular"])) {
            $program = 'Regular';
            $file = $_FILES["import_file_regular"]["tmp_name"];
            $fileName = $_FILES["import_file_regular"]["name"];
        } elseif (isset($_FILES["import_file_weekend"])) {
            $program = 'Weekend';
            $file = $_FILES["import_file_weekend"]["tmp_name"];
            $fileName = $_FILES["import_file_weekend"]["name"];
        } elseif (isset($_FILES["import_file_summer"])) {
            $program = 'Summer';
            $file = $_FILES["import_file_summer"]["tmp_name"];
            $fileName = $_FILES["import_file_summer"]["name"];
        }

        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if (!in_array($fileExt, ['xlsx', 'xls'])) {
            throw new Exception("Invalid file type! Only .xlsx and .xls files are allowed.");
        }

        $spreadsheet = IOFactory::load($file);
        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        $stmt = $pdo->prepare("INSERT INTO students (id, name, gpa, department, gender, entry_date, graduation_date, cost_share, program) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $importedCount = 0;
        foreach ($sheetData as $rowNum => $row) {
            if ($rowNum === 1) continue;

            $stu_id = trim($row['A'] ?? '');
            $stu_name = trim($row['B'] ?? '');
            $stu_gpa = floatval($row['C'] ?? '');
            $stu_dept = trim($row['D'] ?? '');
            $stu_gender = trim($row['E'] ?? '');
            $stu_entry_date = trim($row['F'] ?? '');
            $stu_grad_date = trim($row['G'] ?? '');
            $stu_cost_share = trim($row['H'] ?? '');
            $stu_program = $program;

            if (empty($stu_name) || empty($stu_gpa) || empty($stu_dept) || 
                empty($stu_gender) || empty($stu_entry_date) || empty($stu_grad_date) || 
                empty($stu_cost_share)) {
                continue;
            }

            if ($stu_gpa < 0 || $stu_gpa > 4) {
                continue;
            }

            if (!in_array(strtolower($stu_gender), ['male', 'female'])) {
                continue;
            }

            if (!in_array(strtolower($stu_cost_share), ['paid', 'unpaid'])) {
                continue;
            }

            // Validate ID prefix during import
            if ($stu_program === "Regular" && (!preg_match("/^UGR/", $stu_id) || empty($stu_id))) {
                $stu_id = generateStudentID($pdo, $stu_program);
            } elseif ($stu_program === "Weekend" && (!preg_match("/^UGW/", $stu_id) || empty($stu_id))) {
                $stu_id = generateStudentID($pdo, $stu_program);
            } elseif ($stu_program === "Summer" && (!preg_match("/^UGS/", $stu_id) || empty($stu_id))) {
                $stu_id = generateStudentID($pdo, $stu_program);
            }

            $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE id = ?");
            $checkStmt->execute([$stu_id]);
            if ($checkStmt->fetchColumn() > 0) {
                continue;
            }

            $stmt->execute([$stu_id, $stu_name, $stu_gpa, $stu_dept, $stu_gender, $stu_entry_date, $stu_grad_date, $stu_cost_share, $stu_program]);
            $importedCount++;
        }
        $message = "$program data imported successfully! $importedCount students added.";
    } catch (Exception $e) {
        $message = "Error during $program import: " . $e->getMessage();
    }
}

// Fetch students by program
$regularStmt = $pdo->query("SELECT * FROM students WHERE program = 'Regular' ORDER BY id");
$regularStudents = $regularStmt->fetchAll(PDO::FETCH_ASSOC);

$weekendStmt = $pdo->query("SELECT * FROM students WHERE program = 'Weekend' ORDER BY id");
$weekendStudents = $weekendStmt->fetchAll(PDO::FETCH_ASSOC);

$summerStmt = $pdo->query("SELECT * FROM students WHERE program = 'Summer' ORDER BY id");
$summerStudents = $summerStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-en="Current Students List - Jinka University" data-lang-am="የአሁኑ ተማሪዎች ዝርዝር - ጂንካ ዩኒቨርሲቲ">Current Students List - Jinka University</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/students_list.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>
<body style="background: rgb(235, 216, 235);">
    <div class="container">
        <div class="top-bar">
            <h2 data-lang-en="Current Students List" data-lang-am="የአሁኑ ተማሪዎች ዝርዝር">Current Students List</h2>
            <div>
                <button class="btn lang-toggle" onclick="toggleLanguage()">En | አማ</button>
                <a href="dashboard.php" class="btn back-btn" data-lang-en="Back to Dashboard" data-lang-am="ወደ ዳሽቦርድ ተመለስ">Back to Dashboard</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="<?php echo strpos($message, 'Error') === false ? 'message' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="manage-section" style="background: rgb(200, 200, 200);">
            <h3 data-lang-en="Student Information" data-lang-am="የተማሪ መረጃ"><?php echo $editData ? 'Edit Student Information' : 'Add Student Information'; ?></h3>
            <form class="manage-form" method="post" enctype="multipart/form-data">
                <?php if ($editData): ?>
                    <input type="text" name="stu-id" placeholder="Student ID" value="<?php echo htmlspecialchars($editData["id"] ?? ''); ?>" required readonly>
                <?php else: ?>
                    <input type="text" name="stu-id" id="stu-id" placeholder="Student ID (e.g., UGR001)" readonly>
                <?php endif; ?>
                <input type="text" name="stu-name" placeholder="Name" value="<?php echo htmlspecialchars($editData["name"] ?? ''); ?>" required>
                <input type="number" name="stu-gpa" placeholder="Current GPA" step="0.01" min="0" max="4" value="<?php echo htmlspecialchars($editData["gpa"] ?? ''); ?>" required>
                <select name="stu-dept" required>
                    <option value="">Select Department</option>
                    <option value="Agricultural Economics" <?php echo ($editData && $editData["department"] == "Agricultural Economics") ? 'selected' : ''; ?>>Agricultural Economics</option>
                    <option value="Animal Science" <?php echo ($editData && $editData["department"] == "Animal Science") ? 'selected' : ''; ?>>Animal Science</option>
                    <option value="Natural Resource Management" <?php echo ($editData && $editData["department"] == "Natural Resource Management") ? 'selected' : ''; ?>>Natural Resource Management</option>
                    <option value="Plant Science" <?php echo ($editData && $editData["department"] == "Plant Science") ? 'selected' : ''; ?>>Plant Science</option>
                    <option value="Biology" <?php echo ($editData && $editData["department"] == "Biology") ? 'selected' : ''; ?>>Biology</option>
                    <option value="Chemistry" <?php echo ($editData && $editData["department"] == "Chemistry") ? 'selected' : ''; ?>>Chemistry</option>
                    <option value="Mathematics" <?php echo ($editData && $editData["department"] == "Mathematics") ? 'selected' : ''; ?>>Mathematics</option>
                    <option value="Physics" <?php echo ($editData && $editData["department"] == "Physics") ? 'selected' : ''; ?>>Physics</option>
                    <option value="English Language and Literature" <?php echo ($editData && $editData["department"] == "English Language and Literature") ? 'selected' : ''; ?>>English Language and Literature</option>
                    <option value="Geography" <?php echo ($editData && $editData["department"] == "Geography") ? 'selected' : ''; ?>>Geography</option>
                    <option value="History and Heritage Management" <?php echo ($editData && $editData["department"] == "History and Heritage Management") ? 'selected' : ''; ?>>History and Heritage Management</option>
                    <option value="Accounting and Finance" <?php echo ($editData && $editData["department"] == "Accounting and Finance") ? 'selected' : ''; ?>>Accounting and Finance</option>
                    <option value="Economics" <?php echo ($editData && $editData["department"] == "Economics") ? 'selected' : ''; ?>>Economics</option>
                    <option value="Management" <?php echo ($editData && $editData["department"] == "Management") ? 'selected' : ''; ?>>Management</option>
                    <option value="Health Officer" <?php echo ($editData && $editData["department"] == "Health Officer") ? 'selected' : ''; ?>>Health Officer</option>
                    <option value="Midwife Nurse" <?php echo ($editData && $editData["department"] == "Midwife Nurse") ? 'selected' : ''; ?>>Midwife Nurse</option>
                    <option value="Nursing" <?php echo ($editData && $editData["department"] == "Nursing") ? 'selected' : ''; ?>>Nursing</option>
                    <option value="Computer Science" <?php echo ($editData && $editData["department"] == "Computer Science") ? 'selected' : ''; ?>>Computer Science</option>
                    <option value="Anthropology" <?php echo ($editData && $editData["department"] == "Anthropology") ? 'selected' : ''; ?>>Anthropology</option>
                    <option value="HPE" <?php echo ($editData && $editData["department"] == "HPE") ? 'selected' : ''; ?>>HPE</option>
                    <option value="AgriBusiness" <?php echo ($editData && $editData["department"] == "AgriBusiness") ? 'selected' : ''; ?>>AgriBusiness</option>
                    <option value="Law" <?php echo ($editData && $editData["department"] == "Law") ? 'selected' : ''; ?>>Law</option>
                </select>
                <select name="stu-gender" required>
                    <option value="">Select Gender</option>
                    <option value="Male" <?php echo ($editData && $editData["gender"] == "Male") ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?php echo ($editData && $editData["gender"] == "Female") ? 'selected' : ''; ?>>Female</option>
                </select>
                <input type="text" name="stu-entry-date" class="flatpickr-input" placeholder="Entry Date" value="<?php echo htmlspecialchars($editData["entry_date"] ?? ''); ?>" required>
                <input type="text" name="stu-grad-date" class="flatpickr-input" placeholder="Graduation Date" value="<?php echo htmlspecialchars($editData["graduation_date"] ?? ''); ?>" required>
                <select name="stu-cost-share" required>
                    <option value="">Cost Share Status</option>
                    <option value="paid" <?php echo ($editData && $editData["cost_share"] == "paid") ? 'selected' : ''; ?>>Paid</option>
                    <option value="unpaid" <?php echo ($editData && $editData["cost_share"] == "unpaid") ? 'selected' : ''; ?>>Unpaid</option>
                </select>
                <select name="stu-program" id="stu-program" required>
                    <option value="">Select Program</option>
                    <option value="Regular" <?php echo ($editData && $editData["program"] == "Regular") ? 'selected' : ''; ?>>Regular</option>
                    <option value="Weekend" <?php echo ($editData && $editData["program"] == "Weekend") ? 'selected' : ''; ?>>Weekend</option>
                    <option value="Summer" <?php echo ($editData && $editData["program"] == "Summer") ? 'selected' : ''; ?>>Summer</option>
                </select>
                <input type="file" name="stu-photo" accept="image/*">
                <input type="hidden" name="existing-photo" value="<?php echo htmlspecialchars($editData["photo"] ?? ''); ?>">
                <?php if ($editData): ?>
                    <button type="submit" name="update_stu" class="btn update-btn" data-lang-en="Update Student" data-lang-am="ተማሪ ዘምን">Update Student</button>
                <?php else: ?>
                    <button type="submit" name="add_stu" class="btn add-btn" data-lang-en="Add Student" data-lang-am="ተማሪ ጨምር">Add Student</button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Regular Students Table -->
        <div class="table-container" style="background: rgb(200, 200, 200);">
            <h3 data-lang-en="Regular Students" data-lang-am="መደበኛ ተማሪዎች">Regular Students</h3>
            <div style="margin-bottom: 1rem;">
                <a href="?export_program=Regular" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
                <form method="post" enctype="multipart/form-data" style="display: inline;">
                    <input type="file" name="import_file_regular" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                    <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
                </form>
            </div>
            <form method="post" id="deleteFormRegular">
                <div style="margin-bottom: 1rem;">
                    <span class="select-all" onclick="toggleSelectAll('Regular')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                    <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                            onclick="return confirm('Are you sure you want to delete selected students?')" 
                            data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAllRegular" class="checkbox"></th>
                            <th data-lang-en="Student ID" data-lang-am="የተማሪ መለያ">Student ID</th>
                            <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                            <th data-lang-en="GPA" data-lang-am="GPA">GPA</th>
                            <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                            <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                            <th data-lang-en="Entry Date" data-lang-am="የመግቢያ ቀን">Entry Date</th>
                            <th data-lang-en="Graduation Date" data-lang-am="የመመረቂያ ቀን">Graduation Date</th>
                            <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                            <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                            <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                            <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($regularStudents as $row): ?>
                            <tr>
                                <td><input type="checkbox" name="selected_students[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox stu-checkbox-regular"></td>
                                <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gpa"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["entry_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                                <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                                <td>
                                    <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                    <a href="?delete_stu=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <!-- Weekend Students Table -->
        <div class="table-container" style="background: rgb(200, 200, 200);">
            <h3 data-lang-en="Weekend Students" data-lang-am="የሳምንት መጨረሻ ተማሪዎች">Weekend Students</h3>
            <div style="margin-bottom: 1rem;">
                <a href="?export_program=Weekend" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
                <form method="post" enctype="multipart/form-data" style="display: inline;">
                    <input type="file" name="import_file_weekend" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                    <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
                </form>
            </div>
            <form method="post" id="deleteFormWeekend">
                <div style="margin-bottom: 1rem;">
                    <span class="select-all" onclick="toggleSelectAll('Weekend')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                    <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                            onclick="return confirm('Are you sure you want to delete selected students?')" 
                            data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAllWeekend" class="checkbox"></th>
                            <th data-lang-en="Student ID" data-lang-am="የተማሪ መለያ">Student ID</th>
                            <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                            <th data-lang-en="GPA" data-lang-am="GPA">GPA</th>
                            <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                            <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                            <th data-lang-en="Entry Date" data-lang-am="የመግቢያ ቀን">Entry Date</th>
                            <th data-lang-en="Graduation Date" data-lang-am="የመመረቂዪ ቀን">Graduation Date</th>
                            <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                            <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                            <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                            <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($weekendStudents as $row): ?>
                            <tr>
                                <td><input type="checkbox" name="selected_students[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox stu-checkbox-weekend"></td>
                                <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gpa"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["entry_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                                <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                                <td>
                                    <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                    <a href="?delete_stu=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <!-- Summer Students Table -->
        <div class="table-container" style="background: rgb(200, 200, 200);">
            <h3 data-lang-en="Summer Students" data-lang-am="የበጋ ተማሪዎች">Summer Students</h3>
            <div style="margin-bottom: 1rem;">
                <a href="?export_program=Summer" class="btn export-btn" data-lang-en="Export to Excel" data-lang-am="ወደ ኤክሴል ላክ">Export to Excel</a>
                <form method="post" enctype="multipart/form-data" style="display: inline;">
                    <input type="file" name="import_file_summer" accept=".xlsx, .xls" required style="display: inline-block; margin-left: 1rem;">
                    <button type="submit" class="btn import-btn" data-lang-en="Import from Excel" data-lang-am="ከኤክሴል አስመጣ">Import from Excel</button>
                </form>
            </div>
            <form method="post" id="deleteFormSummer">
                <div style="margin-bottom: 1rem;">
                    <span class="select-all" onclick="toggleSelectAll('Summer')" data-lang-en="Select All" data-lang-am="ሁሉንም ምረጥ">Select All</span>
                    <button type="submit" name="delete_selected" class="btn delete-selected-btn" 
                            onclick="return confirm('Are you sure you want to delete selected students?')" 
                            data-lang-en="Delete Selected" data-lang-am="የተመረጡትን ሰርዝ">Delete Selected</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAllSummer" class="checkbox"></th>
                            <th data-lang-en="Student ID" data-lang-am="የተማሪ መለያ">Student ID</th>
                            <th data-lang-en="Name" data-lang-am="ስም">Name</th>
                            <th data-lang-en="GPA" data-lang-am="GPA">GPA</th>
                            <th data-lang-en="Department" data-lang-am="ዲፓርትመንት">Department</th>
                            <th data-lang-en="Gender" data-lang-am="ፆታ">Gender</th>
                            <th data-lang-en="Entry Date" data-lang-am="የመግቢያ ቀን">Entry Date</th>
                            <th data-lang-en="Graduation Date" data-lang-am="የመመረቂያ ቀን">Graduation Date</th>
                            <th data-lang-en="Cost Share" data-lang-am="ወጪ መጋራት">Cost Share</th>
                            <th data-lang-en="Program" data-lang-am="ፕሮግራም">Program</th>
                            <th data-lang-en="Photo" data-lang-am="ፎቶ">Photo</th>
                            <th data-lang-en="Actions" data-lang-am="ተግባራት">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($summerStudents as $row): ?>
                            <tr>
                                <td><input type="checkbox" name="selected_students[]" value="<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="checkbox stu-checkbox-summer"></td>
                                <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["name"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gpa"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["department"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["gender"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["entry_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["graduation_date"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["cost_share"] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row["program"] ?? ''); ?></td>
                                <td><?php echo $row["photo"] ? '<img src="uploads/' . htmlspecialchars($row["photo"]) . '" alt="Photo" width="50">' : ''; ?></td>
                                <td>
                                    <a href="?edit_id=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn edit-btn" data-lang-en="Edit" data-lang-am="አርም">Edit</a>
                                    <a href="?delete_stu=<?php echo htmlspecialchars($row["id"] ?? ''); ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?')" data-lang-en="Delete" data-lang-am="ሰርዝ">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>

    <footer style="background: black;">
    <?php

include 'footer.php';

    ?>
</footer>
    <script src="assets/js/students_list.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr(".flatpickr-input", {
                dateFormat: "Y-m-d",
                enableTime: false,
                defaultDate: "<?php echo $editData ? ($editData['entry_date'] ?? $editData['graduation_date']) : ''; ?>"
            });

            <?php if (!$editData): ?>
            const programSelect = document.getElementById('stu-program');
            const idInput = document.getElementById('stu-id');

            programSelect.addEventListener('change', function() {
                const program = this.value;
                let defaultId = '';
                switch (program) {
                    case 'Regular':
                        defaultId = 'UGR001';
                        break;
                    case 'Weekend':
                        defaultId = 'UGW001';
                        break;
                    case 'Summer':
                        defaultId = 'UGS001';
                        break;
                    default:
                        defaultId = '';
                }
                idInput.value = defaultId;
                idInput.placeholder = `Student ID (e.g., ${defaultId})`;
            });

            if (programSelect.value) {
                programSelect.dispatchEvent(new Event('change'));
            }
            <?php else: ?>
            const stuId = document.querySelector('input[name="stu-id"]').value;
            const stuProgram = document.querySelector('select[name="stu-program"]').value;
            <?php endif; ?>
        });

        document.querySelector('.manage-form').addEventListener('submit', function(e) {
            const gpa = parseFloat(document.querySelector('input[name="stu-gpa"]').value);
            if (gpa < 0 || gpa > 4) {
                e.preventDefault();
                alert('GPA must be between 0 and 4');
                return false;
            }

            <?php if (!$editData): ?>
            const stuProgram = document.querySelector('select[name="stu-program"]').value;
            const stuId = document.querySelector('input[name="stu-id"]').value;
            if (stuProgram === 'Regular' && !stuId.startsWith('UGR')) {
                e.preventDefault();
                alert("Regular program ID must start with 'UGR'!");
                return false;
            } else if (stuProgram === 'Weekend' && !stuId.startsWith('UGW')) {
                e.preventDefault();
                alert("Weekend program ID must start with 'UGW'!");
                return false;
            } else if (stuProgram === 'Summer' && !stuId.startsWith('UGS')) {
                e.preventDefault();
                alert("Summer program ID must start with 'UGS'!");
                return false;
            }
            <?php else: ?>
            const stuId = document.querySelector('input[name="stu-id"]').value;
            const stuProgram = document.querySelector('select[name="stu-program"]').value;
            if (stuProgram === 'Regular' && !stuId.startsWith('UGR')) {
                e.preventDefault();
                alert("Regular program ID must start with 'UGR'!");
                return false;
            } else if (stuProgram === 'Weekend' && !stuId.startsWith('UGW')) {
                e.preventDefault();
                alert("Weekend program ID must start with 'UGW'!");
                return false;
            } else if (stuProgram === 'Summer' && !stuId.startsWith('UGS')) {
                e.preventDefault();
                alert("Summer program ID must start with 'UGS'!");
                return false;
            }
            <?php endif; ?>
        });
    </script>
</body>
</html>