<?php
session_start();
header("Content-Type: text/html;charset=UTF-8");

$host = "localhost";
$dbname = "jinka_university";
$dbUser = "root"; // Adjust as needed
$dbPass = "";     // Adjust as needed

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname", $dbUser, $dbPass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);

    if (empty($username) || empty($password)) {
        header("Location: login.php?error=" . urlencode("Please fill in all fields. | እባክዎ ሁሉንም መስኮች ይሙሉ።"));
        exit;
    }

    $stmt = $db->prepare("SELECT username, password, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user["password"] === $password) {
        $_SESSION["user"] = $user["username"];
        $_SESSION["role"] = $user["role"];
        header("Location: dashboard.php");
        exit;
    } else {
        header("Location: login.php?error=" . urlencode("Invalid username or password. | የተሳሳተ ስም ወይም የይለፍ ቃል።"));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-en="Login - Jinka University" data-lang-am="መግቢያ - ጂንካ ዩኒቨርሲቲ">Login - Jinka University</title>
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body style="background: rgb(235, 216, 235);">
    <header>
        <div class="nav-controls">
            <button class="btn lang-btn" onclick="toggleLanguage()">En | አማ</button>
            <a href="index.html" class="btn back-btn" data-lang-en="Back to Home" data-lang-am="ወደ መነሻ ተመለስ">Back to Home</a>
        </div>
    </header>

    <main>
        <div class="login-container">
            <h2 data-lang-en="Admin/Registrar Login" data-lang-am="አስተዳዳሪ/ሪጂስትራር መግቢያ">Admin/Registrar Login</h2>
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="username" data-lang-en="Username" data-lang-am="የተጠቃሚ ስም">Username</label>
                    <input type="text" id="username" name="username" 
                           data-lang-en="Enter username" data-lang-am="የተጠቃሚ ስም አስገባ" 
                           placeholder="Enter username" required>
                </div>
                <div class="form-group">
                    <label for="password" data-lang-en="Password" data-lang-am="የይለፍ ቃል">Password</label>
                    <input type="password" id="password" name="password" 
                           data-lang-en="Enter password" data-lang-am="የይለፍ ቃል አስገባ" 
                           placeholder="Enter password" required>
                </div>
                <button type="submit" class="login-btn" data-lang-en="Login" data-lang-am="ግባ">Login</button>
            </form>
            <?php if (isset($_GET["error"])) { echo "<p class='error'>" . htmlspecialchars($_GET["error"]) . "</p>"; } ?>
        </div>
    </main>

    <footer style="background: black;">
    <?php

include 'footer.php';

    ?>
</footer>

    <script src="assets/js/login.js"></script>
</body>
</html>