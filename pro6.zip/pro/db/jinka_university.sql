-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2025 at 08:48 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jinka_university`
--

-- --------------------------------------------------------

--
-- Table structure for table `graduates`
--

CREATE TABLE `graduates` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `cgpa` decimal(3,2) DEFAULT NULL,
  `exit_exam` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `graduation_date` date DEFAULT NULL,
  `cost_share` varchar(10) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `verification_code` varchar(6) DEFAULT NULL,
  `program` enum('Regular','Weekend','Summer') NOT NULL DEFAULT 'Regular',
  `qualification` varchar(10) NOT NULL DEFAULT 'BSc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `graduates`
--

INSERT INTO `graduates` (`id`, `name`, `cgpa`, `exit_exam`, `department`, `gender`, `graduation_date`, `cost_share`, `photo`, `verification_code`, `program`, `qualification`) VALUES
('UGR/14158/', 'gdfgsegdgfgdffffffffffffffffffffffff', 3.50, '85', 'Nursing', 'Male', '2025-03-19', 'paid', '67ea284e96a38.png', 'JkU031', 'Regular', 'BSc'),
('UGR/145265', 'YUYUYUYU', 3.60, '85', 'Computer Science', 'Male', '2025-03-12', 'paid', '67db2cbd17ebc.png', 'JkU024', 'Weekend', 'BSc'),
('UGR0001', 'rdewws', 2.60, NULL, 'Animal Science', 'Female', '2025-03-20', 'paid', '67dabcb3ca293.png', 'JkU028', 'Regular', 'BSc'),
('UGR0002', 'Ramato Kemal Shifa', 2.60, NULL, 'Anthropology', 'Male', '2025-03-19', 'unpaid', '67dabcca870d0.png', 'JkU022', 'Regular', 'BSc'),
('UGS/145275', 'YUYUYUYU', 3.60, '85', 'Health Officer', 'Male', '2025-03-06', 'paid', '67db2ce86cde5.png', 'JkU025', 'Summer', 'BSc'),
('UGS001', 'asweds', 2.50, NULL, 'Midwife Nurse', 'Female', '2025-03-20', 'paid', '67db38cebca5e.png', 'JkU029', 'Summer', 'BSc'),
('UGW001', 'grdsdsd', 3.20, NULL, 'Animal Science', 'Male', '2025-03-20', 'paid', '67db388135898.png', 'JkU030', 'Weekend', 'BSc');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `entry_date` varchar(15) DEFAULT NULL,
  `cost_share` varchar(10) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `program` enum('Regular','Weekend','Summer') NOT NULL DEFAULT 'Regular',
  `graduation_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `gpa`, `department`, `gender`, `entry_date`, `cost_share`, `photo`, `program`, `graduation_date`) VALUES
('UGR0002', 'raeerfdghjdfg', 3.60, 'Economics', 'Female', '2021-03-04', 'paid', '67db350c2e682.png', 'Regular', '2025-03-21'),
('UGS001', 'efryhgsdxfhfgdf', 2.90, 'Animal Science', 'Male', '2023-03-03', 'paid', '67db59e34b3b1.png', 'Summer', '2025-03-27'),
('UGW001', 'gdrtfg hjv ', 2.90, 'Nursing', 'Male', '2021-03-12', 'paid', '67db5d5dddfd7.png', 'Weekend', '2025-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` enum('admin','registrar') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`, `active`) VALUES
(1, 'admin', 'admin123', 'admin', '2025-02-27 00:28:58', 1),
(2, 'registrar', 'reg456', 'registrar', '2025-02-27 00:28:58', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `graduates`
--
ALTER TABLE `graduates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `verification_code` (`verification_code`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
